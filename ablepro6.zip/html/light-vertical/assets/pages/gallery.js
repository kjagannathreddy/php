  'use strict';
$(document).ready(function(){
		$('#lightgallery div').lightGallery();
		$('#lightgallery1 div').lightGallery();
	});