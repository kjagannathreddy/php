$(document).ready(function () {
    $(".form_info").show();
    $("#service_provider").hide();
    $(".secondform_info").hide();
    $(".fourth_info").hide();
    $(".fifth_info").hide();
    $(".appointment").hide();
    $(".appointment_error").hide();
    $(".bookingconfirmation").hide();
    $(".credit_card_data").hide();
    $("#step_one").addClass("active");
    $("#empdetails").hide();
    $("#forgotpassword").hide();
    $(".colorappointmentrequest").hide();
    $('#forgotpasswordlogin').hide();
    $('#schudule').hide();
    $('#search1').hide();
    $('#search2').hide();
    $('#search3').hide();
    $('#search4').hide();
    $('#search5').hide();

    var pop = getCookie("lpopup");
    if (pop != "") {
        $("#locations").hide();
    } else {
        $("#locations").fadeIn();
    }
    var todaysDate = new Date();
    var pastDate = new Date();
    var dp = $(".datepicker").kendoDatePicker({
        value: pastDate,
        min: pastDate,
        change: function (e) {
            var aptfromdate = $("#aptfromdate").val();
            var aptfromdate = aptfromdate.split("/");
            var aptfromdate = (aptfromdate[0] + "/" + aptfromdate[1] + "/" + aptfromdate[2]);
            var todaysDate = new Date(aptfromdate);
            var pastDate = new Date(aptfromdate);
            $("#apttodate").kendoDatePicker({
                value: pastDate,
                min: pastDate,
                format: "MM/dd/yyyy",
                open: function (e) {
                    if (dp.min() == pastDate) {
                        dp.value(todaysDate);
                        dp.min(todaysDate);
                    }
                }
            }).data("kendoDatePicker").trigger("change");
        },
        format: "MM/dd/yyyy",
        open: function (e) {
            if (dp.min() == pastDate) {
                dp.value(todaysDate);
                dp.min(todaysDate);
            }
        }
    }).data("kendoDatePicker");
    $("#aptfromdate").change(function () {
        $("#cdate").html($("#aptfromdate").val() + " -  " + $("#aptfromdate").val());
        $("#ctime").html($('#apttime option:selected').text());
        $('#schudule').show();
    });
    $("#apttodate").change(function () {
        $("#cdate").html($("#aptfromdate").val() + " -  " + $("#apttodate").val());
        $("#ctime").html($('#apttime option:selected').text());
        $('#schudule').show();
    });
    $("#apttime").change(function () {
        $("#ctime").html($('#apttime option:selected').text());
    });
    $("#birthday").kendoDatePicker({format: "MM/dd/yyyy"});
    $(".selectlist").kendoDropDownList();
    equalheight = function (container) {
        $("#apttodate").kendoDatePicker({
            value: pastDate,
            min: pastDate,
            format: "MM/dd/yyyy",
            open: function (e) {
                if (dp.min() == pastDate) {
                    dp.value(todaysDate);
                    dp.min(todaysDate);
                }
            }
        })

        var currentTallest = 0,
                currentRowStart = 0,
                rowDivs = new Array(),
                $el,
                topPosition = 0;
        $(container).each(function () {

            $el = $(this);
            $($el).height('auto')
            topPostion = $el.position().top;

            if (currentRowStart != topPostion) {
                for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                    rowDivs[currentDiv].height(currentTallest);
                }
                rowDivs.length = 0; // empty the array
                currentRowStart = topPostion;
                currentTallest = $el.height();
                rowDivs.push($el);
            } else {
                rowDivs.push($el);
                currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
            }
            for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                rowDivs[currentDiv].height(currentTallest);
            }
        });
    }
    $(window).load(function () {
        equalheight('');
    });
    $(window).resize(function () {
        equalheight('');
    });
});
function update_creditcard() {

    if ($("#card_type").val() == 0) {
        $("#card_type").focus();
        $(".loader").fadeIn(200);
        $(".loader").html("Please select card type.");
        $(".loader").fadeOut(3000);
        return false;
    }
    var card_type_data = $("#card_type").val().split('-');
    var card_id = card_type_data[0];
    var card_name = card_type_data[1];
    if ($("#card_number").val() == "") {
        $("#card_number").focus();
        $(".loader").fadeIn(200);
        $(".loader").html("Please enter card number.");
        $(".loader").fadeOut(3000);
        return false;
    } else {
        if (card_name == 'AmericanExpress') {
            var cardno = /^(?:3[47][0-9]{13})$/;
        } else if (card_name == 'Visa') {
            var cardno = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
        } else if (card_name == 'MasterCard') {
            var cardno = /^(?:5[1-5][0-9]{14})$/;
        } else if (card_name == 'Discover') {
            var cardno = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;
        } else if (card_name == 'JCB') {
            var cardno = /^(?:(?:2131|1800|35\d{3})\d{11})$/;
        }
        if (!$("#card_number").val().match(cardno)) {
            $("#card_number").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter valid card number.");
            $(".loader").fadeOut(3000);
            alert("false" + $("#card_number").val());
            return false;
        }
    }
    if ($("#expiration_date").val() == "") {
        $("#expiration_date").focus();
        $(".loader").fadeIn(200);
        $(".loader").html("Please enter Card expiration date.");
        $(".loader").fadeOut(3000);
        return false;
    } else {
        var expire = $("#expiration_date").val();
        // get parts of the expiration date
        var sections = expire.split('/');
        if (sections.length !== 2) {
            $("#expiration_date").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("The expiration date is not valid");
            $(".loader").fadeOut(3000);
            return false;
        }
        var year = parseInt(sections[1], 10),
                month = parseInt(sections[0], 10),
                currentMonth = new Date().getMonth() + 1,
                currentYear = new Date().getFullYear();

        if (month <= 0 || month > 12 || year > currentYear + 10) {
            $("#expiration_date").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("The expiration date is not valid");
            $(".loader").fadeOut(3000);
            return false;
        }

        if (year < currentYear || (year == currentYear && month < currentMonth)) {
            // The date is expired
            $("#expiration_date").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("The expiration date is not valid");
            $(".loader").fadeOut(3000);
            return false;
        }

    }
    if ($("#cvv").val() == "") {
        $("#cvv").focus();
        $(".loader").fadeIn(200);
        $(".loader").html("Please enter CVV code.");
        $(".loader").fadeOut(3000);
        return false;
    } else {
        var cvv = $("#cvv").val();
        if (!cvv.match(/^[0-9]{3,4}$/)) {
            $("#cvv").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter valid CVV code.");
            $(".loader").fadeOut(3000);
            return false;
        }
    }

    if ($("#name_on_card").val() == "") {
        $("#name_on_card").focus();
        $(".loader").fadeIn(200);
        $(".loader").html("Please enter Name on card.");
        $(".loader").fadeOut(3000);
        return false;
    }

    var card_number = $("#card_number").val();
    var expiration_date = $("#expiration_date").val();
    var cvv = $("#cvv").val();
    var name_on_card = $("#name_on_card").val();
    var salon_id = document.booking.booking_salon_id.value;
    clientid = document.booking.sess_client_id.value;

    if (salon_id == "") {
        var salon_id = document.booking.salon_id.value;
    }
    var account_id = $("#salon_account_id").val();
    $.ajax({
        url: 'https://www.salonclouds.plus/BookerApi/encrypt_data',
        type: 'post',
        data: 'card_number=' + card_number + '&cvv=' + cvv,
        success: function (response) {
            console.log(response);
            var obje = JSON.parse(response);
            card_number_val = obje['card_number'];
            cvv_val = obje['cvv'];

            $(".loader").html("Please wait processing...");
            $(".loader").fadeIn(200);
            console.log('card_id=' + card_id + '&card_name=' + card_name + '&card_number=' + card_number_val + '&cvv=' + cvv_val + '&name_on_card=' + name_on_card + '&expiration_date=' + expiration_date + '&clientid=' + clientid);
            $.ajax({
                url: 'https://www.salonclouds.plus/BookerApi/update_creditcard/' + salon_id,
                data: 'card_id=' + card_id + '&card_name=' + card_name + '&card_number=' + card_number_val + '&cvv=' + cvv_val + '&name_on_card=' + name_on_card + '&expiration_date=' + expiration_date + '&clientid=' + clientid,
                crossDomain: true,
                type: 'POST',
                success: function (data) {
                    console.log(data);
                    //return false;
                    var obj = JSON.parse(data);

                    if (obj["status"] == 1) {

                        steps(6);
                    } else {
                        $(".loader").fadeOut(200);
                        $(".loader").html('<p>An error has occurred while updating.</p>');
                        $(".loader").fadeOut(3000);
                        //$(".appointment").show();
                        return false;
                    }
                }
            });

        }
    });


}
function loadloc(account_id) {
    setCookie('lpopup', 'yes', 1);
    location.href = "https://www.salonclouds.plus/booker/onlinebooking/" + account_id;
}
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function loadservices(cid, salon_id, services_id) {
    $("#services" + services_id).html('<option value="">--Select--</option>');
    $("#services" + services_id).selectpicker("refresh");
    $("#employeesid" + services_id).html('<option data-tokens="any" value="0">Any employee</option><option data-tokens="specific" value="1">Specific employee</option>');
    $('#employeesid' + services_id).selectpicker("refresh");
    $(".loader").html("Please wait loading services.");
    $(".loader").fadeIn(200);
    $.post("https://www.salonclouds.plus/BookerApi_web/GetServiceListingByCategory", {cid: cid, salon_id: salon_id})
            .done(function (data) {
                console.log(data);//return false;
                $(".loader").fadeOut(200);
                var obj = JSON.parse(data);

                listItems = '<option value="">--Select--</option>';
                for (var x = 0; x < data.length; x++) {
                    listItems += "<option value='" + obj['services'][x]['serviceID'] + "' data-tokens='" + obj['services'][x]['serviceName'] + "'>" + obj['services'][x]['serviceName'] + "</option>";
                    $("#services" + services_id).html(listItems);/* +"($"+obj['services'][x]['service_price']['from']+" - $"+obj['services'][x]['service_price']['to']+") */
                    $("#services" + services_id).selectpicker("refresh");
                }
            });
}
function loadmultiservices(cid, salon_id, services_id) {
    $("#services" + services_id).html('<option value="">--Select--</option>');
    $("#services" + services_id).selectpicker("refresh");
    $("#employeesid" + services_id).html('<option data-tokens="any" value="0">Any employee</option><option data-tokens="specific" value="1">Specific employee</option>');
    $('#employeesid' + services_id).selectpicker("refresh");
    $(".loader").html("Please wait loading services.");
    $(".loader").fadeIn(200);
    $.post("https://www.salonclouds.plus/BookerApi_web/GetServiceListingByCategory", {cid: cid, salon_id: salon_id})
            .done(function (data) {
                $(".loader").fadeOut(200);
                var obj = JSON.parse(data);
                listItems = "";
                for (var x = 0; x < data.length; x++) {
                    listItems += "<option value='" + obj['services'][x]['serviceID'] + "' data-tokens='" + obj['services'][x]['serviceName'] + "'>" + obj['services'][x]['serviceName'] + "</option>";
                    $("#services" + services_id).html(listItems);    /* ($"+obj['services'][x]['service_price']['from']+" - $"+obj['services'][x]['service_price']['to']+") */
                    $("#services" + services_id).selectpicker("refresh");
                }
            });
}
function refreshemp(id) {
    $("#employeesid" + id).html('<option data-tokens="any" value="0">Any employee</option><option data-tokens="specific" value="1">Specific employee</option>');
    $('#employeesid' + id).selectpicker("refresh");
    cart = "";
    //alert(document.form.elements["service[]"].length);   //((document.getElementsByClassName("selected_services").length)-2)
    var s = 1;
    for (var c = 0; c <= parseInt($(".plus").attr("data-id")) - 1; c++) {
        if ($('#services' + (c) + ' option:selected').text() != "") {
            //$('#search'+(c+1)).show();
            $("#search" + (c + 1)).show();
            $('#ssno' + (c + 1)).html(s);
            $('#ser' + (c + 1)).html($('#services' + (c) + ' option:selected').text());
            $('#emp' + (c + 1)).html($('#employeesid' + (c) + ' option:selected').text());
            //cart += "<ul><li class='clearfix'><label>#"+ (c+1) +"&nbsp;Service:</label> " + $('#services'+c+' option:selected').text() + "</li><li class='clearfix'><label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Employee:</label> " + $('#employeesid'+c+' option:selected').text() +"</li></ul>";
            s++;
        }

    }

}
function getEmployee(eid, serviceid, salon_id) { //alert(eid+" "+serviceid+" "+salon_id);
    if (eid != '0') {
        var serid = $("#services" + serviceid).val();
        $(".loader").html("Please wait loading employees.");
        $(".loader").fadeIn(200);
        $.post("https://www.salonclouds.plus/BookerApi_web/GetEmployeeByService", {service_id: serid, salon_id: salon_id, eid: serviceid})
                .done(function (data) {
                    if (data != "") {
                        $(".loader").fadeOut(200);
                        $("#service_provider").fadeIn(200);
                        $(".employeelist").html(data);
                    } else {
                        $(".loader").html("Oops, sorry no data found. please choose any employee.");   //&#x2639;
                        $(".loader").fadeOut(8000);
                    }
                });
        $('#emp' + (serviceid + 1)).html($('#employeesid' + (serviceid) + ' option:selected').text());
    } else {
        $('#EmployeeId').val(0);
        $('#emp' + (serviceid + 1)).html("Any employee");
    }
}
function getmultiEmployee(eid, serviceid, salon_id) {
    var serid = $("#services" + serviceid).val();
    if (eid != '0') {
        $(".loader").html("Please wait loading employees.");
        $(".loader").fadeIn(200);
        $.post("https://www.salonclouds.plus/BookerApi_web/GetEmployeeByService", {service_id: serid, salon_id: salon_id})
                .done(function (data) {
                    if (data != "") {
                        $(".loader").fadeOut(200);
                        $("#service_provider").fadeIn(200);
                        $(".employeelist").html(data);
                    } else {
                        $(".loader").html("Oops, sorry no data found. please choose any employee.");   //&#x2639;
                        $(".loader").fadeOut(8000);
                    }
                });
    } else {
        $('#EmployeeId').val(0);
    }
}
function getemp(id) {
    if ($('input[name="employee_iid"]:checked').length <= 0) {
        alert("Please choose a service provider.");
        $('#EmployeeId').val(0);
    } else {
        $('#EmployeeId').val($('input[name="employee_iid"]:checked').val());
        $("#service_provider").fadeOut(200);//alert($('input[name="mployee_iid[]"] option[value='+$('input[name="employee_iid"]:checked').val()+']').length);        
        if ($("#employeesid" + id + ' option[value=' + $('input[name="employee_iid"]:checked').val() + ']').length <= 0) {
            daySelect = document.getElementById("employeesid" + id);
            daySelect.options[daySelect.options.length] = new Option($('input[name="employee_iid"]:checked').attr("data-ename"), $('input[name="employee_iid"]:checked').val());
        }
        $("#employeesid" + id + ' option[value=' + $('input[name="employee_iid"]:checked').val() + ']').attr('selected', 'selected');
        $("#employeesid" + id).find('option[value=' + $('input[name="employee_iid"]:checked').val() + ']').prop('selected', 'selected');
        $("#employeesid" + id).selectpicker("refresh");
        $('#emp' + (id + 1)).html($('#employeesid' + (id) + ' option:selected').text());
    }
}
function changebg(emp) {
    $("#employees li").removeClass('em-selector-active');
    $(emp).addClass('em-selector-active');
}
function serealizeSelectsText(select)
{
    var array = [];
    select.each(function () {
        if ($(this).find('option:selected').text() != "" && $.inArray($(this).find('option:selected').text(), array) === -1) {
            array.push($(this).find('option:selected').text())
        }
    });
    return array;
}
function serealizeSelects(select)
{
    var array = [];
    select.each(function () {
        if ($(this).val() != "" && $.inArray($(this).val(), array) === -1) {
            array.push($(this).val())
        }
    });
    return array;
}
function serealizeemployees(select)
{
    var array = [];
    select.each(function () {
        if ($(this).val() != "") {
            array.push($(this).val())
        }
    });
    return array;
}
function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}
function todayopenings(timezone) {

    $('#schudule').show();
    $("#cdate").html("Today");
    $("#ctime").html("Any time");
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd;
    }

    if (mm < 10) {
        mm = '0' + mm;
    }

    today = mm + '/' + dd + '/' + yyyy;

    $("#apttodate").val(today);
    $("#aptfromdate").val(today);

    var aptfdate = ((yyyy) + '-' + mm + '-' + dd);
    var apttdate = ((yyyy) + '-' + mm + '-' + dd);

    var FromTime = '0800';
    var ToTime = '2100';
    $("#bookcontet").html("");
    $(".loader").html("Please wait searching for today openings...");
    $(".loader").fadeIn(200);
    var EmployeeId = document.booking.EmployeeIds.value;
    var salon_account_id = document.booking.salon_account_id.value;
    var salon_id = document.booking.salon_id.value;
    //alert(($('.selected_services').find('option:selected').text()))
    ServiceId = serealizeSelects($('.selected_services'));
    EmployeeId = serealizeemployees($('.selected_employees'));
    ServiceNames = serealizeSelectsText($('.selected_services'));
    ServiceId = ServiceId.join(", ");
    EmployeeId = EmployeeId.join(", ");
    ServiceNames = ServiceNames.join(", ");
    $.post(base_url + "/API/client_scanforopening/" + salon_id, {ServiceIds: ServiceId, EmployeeIds: EmployeeId, ServiceNames: ServiceNames, Date: "today", Time: "anytime"})
            .done(function (data) {
                console.log(data);

                var priceplusSalon = new Array("317", "318", "385");
                if ($.inArray(salon_id, priceplusSalon) !== -1) {
                    var priceplus = " +";
                } else {
                    var priceplus = "";
                }

                $(".loader").fadeOut(200);
                var obj = JSON.parse(data);
                $(".fourth_info").show();
                $(".form_info").hide();
                $(".fifth_info").hide();
                $(".appointment").hide();
                $(".bookingconfirmation").hide();
                $(".credit_card_data").hide();
                $(".secondform_info").hide();
                $(".third_info").hide();
                $("#step_one").removeClass("active");
                $("#step_two").removeClass("active");
                $("#step_three").addClass("active");
                $("#step_four").removeClass("active");
                $("#step_creditcard").removeClass("active");
                listItems = "";
                if (obj['status'] == 1) {
                    if (data.length > 2) {
                        if ((obj['openings']).length != undefined) {
                            var o = 1;
                            var total = 0;
                            EmployeeId = "";
                            ServiceIds = "";
                            StartTime = "";
                            StartLength = "";
                            GapLength = "";
                            FinishLength = "";
                            AppointmentType = "";
                            CheckInTime = "";
                            CheckOutTime = "";
                            ResourceId = "";
                            Genderid = "";
                            ServiceName = "";
                            ServiceEmployee = "";
                            Stime = "";
                            Etime = "";
                            Etime = "";
                            scheduledDate = "";
                            Prices = "";

                            listItems += '<div class="booklist"><ul>';
                            var date = 0;
                            for (var x = 0; x < obj['openings'].length; x++) {

                                var aptdate = new Date(aptfdate);
                                var options = {
                                    weekday: "long", year: "numeric", month: "short",
                                    day: "numeric", hour: "2-digit", minute: "2-digit"
                                };
                                var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                                var aptd = obj['openings'][x]['ddate'].split("-");
                                var pric = (obj['openings'][x]['nprice'] != "-" ? parseFloat(obj['openings'][x]['nprice']).toFixed(2) : "0.00") + priceplus;
                                total = total + pric;
                                if (typeof obj['openings'][x]['employee'] === 'object') {
                                    var cemployee = obj['openings'][x]['employee'];
                                } else {
                                    var cemployee = obj['openings'][x]['employee'];
                                }
                                ServiceIds += obj['openings'][x]['iservid'] + '^';
                                EmployeeId += obj['openings'][x]['iempid'] + '^';
                                StartTime += obj['openings'][x]['apttime'];
                                StartLength += obj['openings'][x]['nstartlen'] + '^';
                                GapLength += obj['openings'][x]['ngaplen'] + '^';
                                FinishLength += obj['openings'][x]['nfinishlen'] + '^';
                                AppointmentType += obj['openings'][x]['iappttype'] + '^';
                                CheckInTime += obj['openings'][x]['cmstarttime'] + '^';
                                CheckOutTime += obj['openings'][x]['cmfinishtime'] + '^';
                                ResourceId += obj['openings'][x]['iresourceid'] + '^';
                                Genderid += obj['openings'][x]['igenderid'] + '^';
                                ServiceName += obj['openings'][x]['service'] + '^';
                                ServiceEmployee += cemployee + '^';
                                Stime += obj['openings'][x]['cmstarttime'] + '^';
                                Etime += obj['openings'][x]['cmfinishtime'] + '^';
                                scheduledDate += obj['openings'][x]['actual_ddate'] + '^';
                                Prices += obj['openings'][x]['nprice'] + '^';
                                listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + (date == 0 ? aptd[1] + "/" + aptd[2] + "/" + aptd[0] : "") + '<br />' + obj['openings'][x]['apttime'] + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['openings'][x]['service'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"><p><span >' + (pric != "0.00" ? "$" + pric : "&nbsp;-&nbsp;") + '</span></p></div></div></li>';
                                date++;
                                if (o % obj['num_services'] == 0) {
                                    listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-Prices="' + Prices + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + obj['openings'][x]['ddate'] + 'T00:00:00" date-ScheduledDate= "' + scheduledDate + '" date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                    if (x != (obj['openings'].length) - 1) {
                                        listItems += '<div class="booklist"><ul>';
                                    }
                                    total = 0;
                                    ServiceIds = "";
                                    EmployeeId = "";
                                    StartTime = "";
                                    StartLength = "";
                                    GapLength = "";
                                    FinishLength = "";
                                    AppointmentType = "";
                                    CheckInTime = "";
                                    CheckOutTime = "";
                                    ResourceId = "";
                                    Genderid = "";
                                    ServiceName = "";
                                    ServiceEmployee = "";
                                    Stime = "";
                                    Etime = "";
                                    date = 0;
                                    scheduledDate = "";
                                    Prices = "";
                                }
                                o++;
                                if (aptdate != "Inv") {
                                    $(".aptdate").html(moment(obj['openings'][0]['ddate']).format('MMMM Do YYYY'));
                                }
                                $("#bookcontet").html(listItems);
                                // $.post(base_url+"/booker/salonname", {salon_id: salon_id}).done(function(data){
                                //  $("#aptloc").html(data);  
                                //  });

                            }
                        } else {
                            var o = 1;
                            var total = 0;
                            EmployeeId = "";
                            ServiceIds = "";
                            StartTime = "";
                            StartLength = "";
                            GapLength = "";
                            FinishLength = "";
                            AppointmentType = "";
                            CheckInTime = "";
                            CheckOutTime = "";
                            ResourceId = "";
                            Genderid = "";
                            ServiceName = "";
                            ServiceEmployee = "";
                            Stime = "";
                            Etime = "";
                            scheduledDate = "";
                            Prices = "";
                            listItems += '<div class="booklist"><ul>';
                            var date = 0;
                            var aptdate = new Date(aptfdate);
                            var options = {
                                weekday: "long", year: "numeric", month: "short",
                                day: "numeric", hour: "2-digit", minute: "2-digit"
                            };
                            var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                            var aptd = obj['openings']['ddate'].split("-");
                            var pric = (obj['openings']['nprice'] != "-" ? parseFloat(obj['openings']['nprice']).toFixed(2) : "0.00") + priceplus;
                            if (typeof obj['openings']['employee'] === 'object') {
                                var cemployee = obj['openings']['employee'];
                            } else {
                            }

                            ServiceIds += obj['openings']['iservid'] + '^';
                            EmployeeId += obj['openings']['iempid'] + '^';
                            StartTime += obj['openings']['apttime'];
                            StartLength += obj['openings']['nstartlen'] + '^';
                            GapLength += obj['openings']['ngaplen'] + '^';
                            FinishLength += obj['openings']['nfinishlen'] + '^';
                            AppointmentType += obj['openings']['iappttype'] + '^';
                            CheckInTime += obj['openings']['cmstarttime'] + '^';
                            CheckOutTime += obj['openings']['cmfinishtime'] + '^';
                            ResourceId += obj['openings']['iresourceid'] + '^';
                            Genderid += obj['openings']['igenderid'] + '^';
                            ServiceName += obj['openings']['service'] + '^';
                            ServiceEmployee += cemployee + '^';
                            Stime += obj['openings']['cmstarttime'] + '^';
                            Etime += obj['openings']['cmfinishtime'] + '^';
                            scheduledDate += obj['openings']['actual_ddate'] + '^';
                            Prices += obj['openings']['nprice'] + '^';
                            listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + (date == 0 ? aptd[1] + "/" + aptd[2] + "/" + aptd[0] : "") + '<br />' + obj['openings']['apttime'] + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['openings']['service'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"><p><span >' + (pric != "0.00" ? "$" + pric : " - ") + '</span></p></div></div></li>';
                            date++;
                            if (o % obj['num_services'] == 0) {
                                listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-Prices="' + Prices + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + obj['openings']['ddate'] + 'T00:00:00" date-ScheduledDate="' + scheduledDate + '"  date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                total = 0;
                                ServiceIds = "";
                                EmployeeId = "";
                                StartTime = "";
                                StartLength = "";
                                GapLength = "";
                                FinishLength = "";
                                AppointmentType = "";
                                CheckInTime = "";
                                CheckOutTime = "";
                                ResourceId = "";
                                Genderid = "";
                                ServiceName = "";
                                ServiceEmployee = "";
                                Stime = "";
                                Etime = "";
                                scheduledDate = "";
                                date = 0;
                                Prices = "";
                            }
                            o++;

                            if (aptdate != "Inv") {
                                $(".aptdate").html(moment(obj['openings']['ddate']).format('MMMM Do YYYY'));
                            }
                            $("#bookcontet").html(listItems);
                            // $.post(base_url+"/booker/salonname", {salon_id: salon_id}).done(function(data){
                            //     $("#aptloc").html(data);  
                            //     });
                        }
                    }
                } else {
                    $("#bookcontet").html("<strong>There were no results based on your current search. please choose another date.</strong>");

                    var aptdate = new Date(today);
                    var options = {
                        weekday: "long", year: "numeric", month: "short",
                        day: "numeric", hour: "2-digit", minute: "2-digit"
                    };
                    var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                    if (aptdate != "Inv") {
                        $(".aptdate").html(moment(aptfdate).format('MMMM Do YYYY'));
                    }
                    //      $.post(base_url+"/booker/salonname", {salon_id: salon_id}).done(function(data){
                    //      $("#aptloc").html(data);  
                    // });

                }
                $.post(base_url + "/booker/salonname", {salon_id: salon_id}).done(function (data) {
                    $("#aptloc").html(data);
                });
            });
}
function gettimeformat(time) {


    var date_format = '12'; /* FORMAT CAN BE 12 hour (12) OR 24 hour (24)*/



    var str = time;
    var hour = str.substring(0, 2);
    var minutes = str.substring(2, 4);
    var result = hour;
    var ext = '';

    if (date_format == '12') {
        if (hour > 12) {
            ext = 'PM';
            hour = (hour - 12);

            if (hour < 10) {
                result = "0" + hour;
            } else if (hour == 12) {
                hour = "00";
                ext = 'AM';
            }
        } else if (hour < 12) {
            result = ((hour < 10) ? hour : hour);
            ext = 'AM';
        } else if (hour == 12) {
            ext = 'PM';
        }
    }

    if (minutes < 10 && minutes != "00") {
        minutes = "0" + minutes;
    }

    result = result + ":" + minutes + ' ' + ext;
    return result;
}
function rescanopenings(ServiceId, FromDate, ToDate, FromTime, ToTime, salon_id) {

    var aptfdate = $("#aptfromdate").val();
    var aptfdate = aptfdate.split("/");
    var FromDate = ((aptfdate[2]) + '-' + aptfdate[0] + '-' + aptfdate[1]);
    if ($("#apttodate").val() != "") {
        var apttdate = $("#apttodate").val();
        var apttdate = apttdate.split("/");
        var ToDate = ((apttdate[2]) + '-' + apttdate[0] + '-' + apttdate[1]);
    } else {
        var ToDate = $("#aptfromdate").val();
    }

//var FromDate="2016-07-19";
//var ToDate="2016-07-19";
//alert( ServiceId + " " + FromDate+ " "+ ToDate+ " "+ FromTime + " " + ToTime+ " " + EmployeeId+ " " + salon_id); 
    $(".loader").html("Please wait searching for openings...");
    $(".loader").fadeIn(200);
    var EmployeeId = "0";
    if ($("#apttime").val() == "anytime") {
        var FromTime = '08:00:00';
        var ToTime = '21:00:00';
    } else if ($("#apttime").val() == "morning") {
        var FromTime = '08:00:00';
        var ToTime = '11:30:00';
    } else if ($("#apttime").val() == "afternoon") {
        var FromTime = '12:00:00';
        var ToTime = '16:30:00';
    } else if ($("#apttime").val() == "evening") {
        var FromTime = '17:00:00';
        var ToTime = '21:00:00';
    } else {
        var FromTime = '08:00:00';
        var ToTime = '21:00:00';
    }
    $.post("https://www.salonclouds.plus/BookerApi_web/ReScanForOpening", {ServiceId: ServiceId, EmployeeId: 0, FromDate: FromDate, ToDate: ToDate, FromTime: FromTime, ToTime: ToTime, salon_id: salon_id})
            .done(function (data) {
                $(".loader").fadeOut(200);
                var obj = JSON.parse(data);
                listItems = "";
                if (obj['GetBookableItemsResult']['ResultCount'] > 0) {
                    //alert(data.length);
                    //alert(obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'].length);             
                    if (data.length > 2) {
                        if (obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'].length != undefined) {

                            var o = 1;
                            var total = 0;
                            EmployeeId = "";
                            ServiceIds = "";
                            StartTime = "";
                            StartLength = "";
                            GapLength = "";
                            FinishLength = "";
                            AppointmentType = "";
                            CheckInTime = "";
                            CheckOutTime = "";
                            ResourceId = "";
                            Genderid = "";
                            ServiceName = "";
                            ServiceEmployee = "";
                            Stime = "";
                            Etime = "";
                            listItems += '<div class="booklist"><ul>';
                            //var EmployeeId = new Array();
                            //var ServiceIds = new Array();
                            var date = 0;
                            for (var x = 0; x < obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'].length; x++) {
                                //alert("herer"); 
                                // alert(obj['openingcur'][x]['cstarttime'] + ' - ' + obj['openingcur'][x]['cfinishtime']);
                                // <span>-</span><p><span>' + obj['openingcur'][x]['cfinishtime'] +'</span></p>
                                var aptdate = new Date(aptfdate);
                                var options = {
                                    weekday: "long", year: "numeric", month: "short",
                                    day: "numeric", hour: "2-digit", minute: "2-digit"
                                };
                                var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                                var aptd = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['StartDateTime'].split("T");
                                var endtime = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['EndDateTime'].split("T");
                                // var pric = parseFloat(obj['ScheduleItems'][x]['nprice']).toFixed(2);
                                //total =total+pric;

                                var cemployee = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['Staff']['Name'];

                                ServiceIds += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['SessionType']['ID'] + '^';
                                EmployeeId += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['Staff']['ID'] + '^';
                                StartTime += aptd[1] + '^';
                                //StartLength += obj['ScheduleItems'][x]['nstartlen'] + '^';
                                //GapLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                                //FinishLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                                // AppointmentType += obj['ScheduleItems'][x]['iappttype'] + '^';
                                // CheckInTime += obj['ScheduleItems'][x]['cmstarttime'] + '^';
                                //CheckOutTime += obj['ScheduleItems'][x]['cmfinishtime'] + '^';
                                // ResourceId += obj['ScheduleItems'][x]['iresourceid'] + '^';
                                // Genderid += obj['ScheduleItems'][x]['igenderid'] + '^';

                                ServiceName += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['SessionType']['Name'] + '^';
                                ServiceEmployee += cemployee + '^';
                                Stime += aptd[1] + '^';
                                Etime += endtime[1] + '^';
                                Prices += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['SessionType']['ID'] + '^';

                                listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + moment(obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['StartDateTime']).format('MM/D/YYYY hh:mm A') + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['SessionType']['Name'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"></div></div></li>';

                                date++;
                                if (o % obj['numser'] == 0) {
                                    listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-Prices="' + Prices + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + aptd[0] + 'T00:00:00" date-ScheduledDate="' + obj['openings'][x]['scheduledDate'] + '"  date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                    if (x != (obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'].length) - 1) {
                                        listItems += '<div class="booklist"><ul>';
                                    }
                                    total = 0;
                                    ServiceIds = "";
                                    EmployeeId = "";
                                    StartTime = "";
                                    StartLength = "";
                                    GapLength = "";
                                    FinishLength = "";
                                    AppointmentType = "";
                                    CheckInTime = "";
                                    CheckOutTime = "";
                                    ResourceId = "";
                                    Genderid = "";
                                    ServiceName = "";
                                    ServiceEmployee = "";
                                    Stime = "";
                                    Etime = "";
                                    date = 0;
                                }
                                o++;
                                //alert(listItems);
                                //if(aptdate!="Inv"){$(".aptdate").html(moment(aptd).format('MMMM Do YYYY'));}
                                $(".aptdate").html(moment(aptd[0]).format('MMMM Do YYYY'));
                                $("#bookcontet").html(listItems);
                                $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: salon_id}).done(function (data) {
                                    $("#aptloc").html(data);
                                });

                            }
                        } else {
                            var o = 1;
                            var total = 0;
                            EmployeeId = "";
                            ServiceIds = "";
                            StartTime = "";
                            StartLength = "";
                            GapLength = "";
                            FinishLength = "";
                            AppointmentType = "";
                            CheckInTime = "";
                            CheckOutTime = "";
                            ResourceId = "";
                            Genderid = "";
                            ServiceName = "";
                            ServiceEmployee = "";
                            Stime = "";
                            Etime = "";
                            listItems += '<div class="booklist"><ul>';
                            var date = 0;

                            var aptdate = new Date(aptfdate);
                            var options = {
                                weekday: "long", year: "numeric", month: "short",
                                day: "numeric", hour: "2-digit", minute: "2-digit"
                            };
                            var aptd = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['StartDateTime'].split("T");
                            var endtime = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['EndDateTime'].split("T");
                            // var pric = parseFloat(obj['ScheduleItems'][x]['nprice']).toFixed(2);
                            //total =total+pric;

                            var cemployee = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['Staff']['Name'];

                            ServiceIds += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['SessionType']['ID'] + '^';
                            EmployeeId += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['Staff']['ID'] + '^';
                            StartTime += aptd[1] + '^';
                            //StartLength += obj['ScheduleItems'][x]['nstartlen'] + '^';
                            //GapLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                            //FinishLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                            // AppointmentType += obj['ScheduleItems'][x]['iappttype'] + '^';
                            // CheckInTime += obj['ScheduleItems'][x]['cmstarttime'] + '^';
                            //CheckOutTime += obj['ScheduleItems'][x]['cmfinishtime'] + '^';
                            // ResourceId += obj['ScheduleItems'][x]['iresourceid'] + '^';
                            // Genderid += obj['ScheduleItems'][x]['igenderid'] + '^';

                            ServiceName += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['SessionType']['Name'] + '^';
                            ServiceEmployee += cemployee + '^';
                            Stime += aptd[1] + '^';
                            Etime += endtime[1] + '^';
                            Prices += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['SessionType']['ID'] + '^';

                            listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + moment(obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['StartDateTime']).format('MM/D/YYYY hh:mm A') + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['SessionType']['Name'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"></div></div></li>';

                            date++;
                            if (o % obj['numser'] == 0) {
                                listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-Prices="' + Prices + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + aptd[0] + 'T00:00:00" date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                total = 0;
                                ServiceIds = "";
                                EmployeeId = "";
                                StartTime = "";
                                StartLength = "";
                                GapLength = "";
                                FinishLength = "";
                                AppointmentType = "";
                                CheckInTime = "";
                                CheckOutTime = "";
                                ResourceId = "";
                                Genderid = "";
                                ServiceName = "";
                                ServiceEmployee = "";
                                Stime = "";
                                Etime = "";
                                date = 0;
                            }
                            o++;


                            //if(aptdate!="Inv"){$(".aptdate").html(moment(obj['openingcur']['ddate']).format('MMMM Do YYYY'));}
                            $(".aptdate").html(moment(aptd[0]).format('MMMM Do YYYY'));
                            $("#bookcontet").html(listItems);
                            $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: salon_id}).done(function (data) {
                                $("#aptloc").html(data);
                            });

                        }
                    }
                } else {
                    $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: salon_id}).done(function (data) {
                        $("#aptloc").html(data);
                    });
                    //$("#bookcontet").html("<strong>Sorry, there were no results based on your current search. </strong>"); 
                    // $("#bookcontet").html(obj['@attributes']['data']); 
                }
            });
}
function steps(step)
{
    if (step == 1)
    {
        /* if($("#service_category").val() == "" ){
         $("#service_category").focus();
         $(".loader").fadeIn(200);
         $(".loader").html("Please choose a service category.");
         $(".loader").fadeOut(2000);
         return false;
         }
         if($("#services0").val() == "" ){
         $("#services0").focus();
         $(".loader").fadeIn(200);
         $(".loader").html("Please choose a service.");
         $(".loader").fadeOut(2000);
         return false;
         } 
         else {}*/
        $(".form_info").hide();
        $(".secondform_info").show();
        $(".fourth_info").hide();
        $(".fifth_info").hide();
        $(".appointment").hide();
        $(".bookingconfirmation").hide();
        $(".credit_card_data").hide();
        $("#step_one").removeClass("active");
        $("#step_two").addClass("active");
        $("#step_three").removeClass("active");
        $("#step_four").removeClass("active");
        $("#step_creditcard").removeClass("active");

    } else if (step == 2)
    {
        //alert("here2");

        $("#booking_confirm_error").hide();
        $(".appointment_error").hide();
        if ($("#aptfromdate").val() == "") {
            $("#aptfromdate").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please choose appointment date.");
            $(".loader").fadeOut(2000);
            return false;
        }
        var aptfdate = $("#aptfromdate").val();
        var aptfdate = aptfdate.split("/");
        var aptfdate = ((aptfdate[2]) + '-' + aptfdate[0] + '-' + aptfdate[1]);
        //ServiceId = $("#services").val();
        if ($("#apttodate").val() != "") {
            var apttdate = $("#apttodate").val();
            var apttdate = apttdate.split("/");
            var apttdate = ((apttdate[2]) + '-' + apttdate[0] + '-' + apttdate[1]);
        } else {
            var apttdate = aptfdate;
        }
        if ($("#apttime").val() == "anytime") {
            var FromTime = '08:00:00';
            var ToTime = '21:00:00';
        } else if ($("#apttime").val() == "morning") {
            var FromTime = '08:00:00';
            var ToTime = '11:30:00';
        } else if ($("#apttime").val() == "afternoon") {
            var FromTime = '12:00:00';
            var ToTime = '16:30:00';
        } else if ($("#apttime").val() == "evening") {
            var FromTime = '17:00:00';
            var ToTime = '21:00:00';
        } else {
            var FromTime = '08:00:00';
            var ToTime = '21:00:00';
        }
        $("#bookcontet").html("");
        $(".loader").html("Please wait searching for openings...");
        $(".loader").fadeIn(200);
        //var EmployeeId = document.booking.EmployeeId.value;
        var salon_account_id = document.booking.salon_account_id.value;
        var salon_id = document.booking.salon_id.value;

        ServiceId = serealizeSelects($('.selected_services'));
        EmployeeId = serealizeemployees($('.selected_employees'));
        ServiceNames = serealizeSelectsText($('.selected_services'));
        ServiceId = ServiceId.join(",");
        EmployeeId = EmployeeId.join(",");
        ServiceNames = ServiceNames.join(", ");

        //document.booking.selectedEmployees.value = EmployeeId; 

        //alert(ServiceNames);return false;
        console.log(ServiceId + " " + aptfdate + " " + apttdate + " " + FromTime + " " + ToTime + " " + EmployeeId + "=" + base_url + "/BookerApi/client_scanforopening/" + salon_id);//return false;
        var atime = $("#apttime").val();
        $.post(base_url + "/API/client_scanforopening/" + salon_id, {ServiceIds: ServiceId, EmployeeIds: EmployeeId, ServiceNames: ServiceNames, Date: "custom", FromDate: aptfdate, ToDate: apttdate, Time: atime})
                .done(function (data) {
                    console.log(data);
                    var priceplusSalon = new Array("317", "318", "385");
                    if ($.inArray(salon_id, priceplusSalon) !== -1) {
                        var priceplus = " +";
                    } else {
                        var priceplus = "";
                    }

                    $(".loader").fadeOut(200);
                    var obj = JSON.parse(data);
                    $(".fourth_info").show();
                    $(".form_info").hide();
                    $(".fifth_info").hide();
                    $(".appointment").hide();
                    $(".bookingconfirmation").hide();
                    $(".credit_card_data").hide();
                    $(".secondform_info").hide();
                    $(".third_info").hide();
                    $("#step_one").removeClass("active");
                    $("#step_two").removeClass("active");
                    $("#step_three").addClass("active");
                    $("#step_four").removeClass("active");
                    $("#step_creditcard").removeClass("active");
                    listItems = "";
                    if (obj['status'] == 1) {
                        if (data.length > 2) {
                            if ((obj['openings']).length != undefined) {
                                var o = 1;
                                var total = 0;
                                EmployeeId = "";
                                ServiceIds = "";
                                StartTime = "";
                                StartLength = "";
                                GapLength = "";
                                FinishLength = "";
                                AppointmentType = "";
                                CheckInTime = "";
                                CheckOutTime = "";
                                ResourceId = "";
                                Genderid = "";
                                ServiceName = "";
                                ServiceEmployee = "";
                                Stime = "";
                                Etime = "";
                                scheduledDate = "";
                                Prices = "";
                                listItems += '<div class="booklist"><ul>';
                                var date = 0;
                                for (var x = 0; x < obj['openings'].length; x++) {

                                    var aptdate = new Date(aptfdate);
                                    var options = {
                                        weekday: "long", year: "numeric", month: "short",
                                        day: "numeric", hour: "2-digit", minute: "2-digit"
                                    };
                                    var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                                    var aptd = obj['openings'][x]['ddate'].split("-");
                                    var pric = (obj['openings'][x]['nprice'] != "-" ? parseFloat(obj['openings'][x]['nprice']).toFixed(2) : "0.00") + priceplus;
                                    total = total + pric;
                                    if (typeof obj['openings'][x]['employee'] === 'object') {
                                        var cemployee = obj['openings'][x]['employee'];
                                    } else {
                                        var cemployee = obj['openings'][x]['employee'];
                                    }
                                    ServiceIds += obj['openings'][x]['iservid'] + '^';
                                    EmployeeId += obj['openings'][x]['iempid'] + '^';
                                    StartTime += obj['openings'][x]['apttime'];
                                    StartLength += obj['openings'][x]['nstartlen'] + '^';
                                    GapLength += obj['openings'][x]['ngaplen'] + '^';
                                    FinishLength += obj['openings'][x]['nfinishlen'] + '^';
                                    AppointmentType += obj['openings'][x]['iappttype'] + '^';
                                    CheckInTime += obj['openings'][x]['cmstarttime'] + '^';
                                    CheckOutTime += obj['openings'][x]['cmfinishtime'] + '^';
                                    ResourceId += obj['openings'][x]['iresourceid'] + '^';
                                    Genderid += obj['openings'][x]['igenderid'] + '^';
                                    ServiceName += obj['openings'][x]['service'] + '^';
                                    ServiceEmployee += cemployee + '^';
                                    Stime += obj['openings'][x]['cmstarttime'] + '^';
                                    Etime += obj['openings'][x]['cmfinishtime'] + '^';
                                    scheduledDate += obj['openings'][x]['actual_ddate'] + '^';
                                    Prices += obj['openings'][x]['nprice'] + '^';
                                    listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + (date == 0 ? aptd[1] + "/" + aptd[2] + "/" + aptd[0] : "") + '<br />' + obj['openings'][x]['apttime'] + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['openings'][x]['service'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"><p><span >' + (pric != "0.00" ? "$" + pric : "&nbsp;-&nbsp;") + '</span></p></div></div></li>';
                                    date++;
                                    if (o % obj['num_services'] == 0) {
                                        listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-Prices="' + Prices + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + obj['openings'][x]['ddate'] + 'T00:00:00"  date-ScheduledDate="' + scheduledDate + '"  date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                        if (x != (obj['openings'].length) - 1) {
                                            listItems += '<div class="booklist"><ul>';
                                        }
                                        total = 0;
                                        ServiceIds = "";
                                        EmployeeId = "";
                                        StartTime = "";
                                        StartLength = "";
                                        GapLength = "";
                                        FinishLength = "";
                                        AppointmentType = "";
                                        CheckInTime = "";
                                        CheckOutTime = "";
                                        ResourceId = "";
                                        Genderid = "";
                                        ServiceName = "";
                                        ServiceEmployee = "";
                                        Stime = "";
                                        Etime = "";
                                        scheduledDate = "";
                                        date = 0;
                                        Prices = 0;
                                    }
                                    o++;
                                    if (aptdate != "Inv") {
                                        $(".aptdate").html(moment(obj['openings'][0]['ddate']).format('MMMM Do YYYY'));
                                    }
                                    $("#bookcontet").html(listItems);
                                    // $.post(base_url+"/booker/salonname", {salon_id: salon_id}).done(function(data){
                                    //  $("#aptloc").html(data);  
                                    //  });

                                }
                            } else {
                                var o = 1;
                                var total = 0;
                                EmployeeId = "";
                                ServiceIds = "";
                                StartTime = "";
                                StartLength = "";
                                GapLength = "";
                                FinishLength = "";
                                AppointmentType = "";
                                CheckInTime = "";
                                CheckOutTime = "";
                                ResourceId = "";
                                Genderid = "";
                                ServiceName = "";
                                ServiceEmployee = "";
                                Stime = "";
                                Etime = "";
                                scheduledDate = "";
                                listItems += '<div class="booklist"><ul>';
                                var date = 0;
                                var aptdate = new Date(aptfdate);
                                var options = {
                                    weekday: "long", year: "numeric", month: "short",
                                    day: "numeric", hour: "2-digit", minute: "2-digit"
                                };
                                var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                                var aptd = obj['openings']['ddate'].split("-");
                                var pric = (obj['openings']['nprice'] != "-" ? parseFloat(obj['openings']['nprice']).toFixed(2) : "0.00") + priceplus;
                                if (typeof obj['openings']['employee'] === 'object') {
                                    var cemployee = obj['openings']['employee'];
                                } else {
                                }

                                ServiceIds += obj['openings']['iservid'] + '^';
                                EmployeeId += obj['openings']['iempid'] + '^';
                                StartTime += obj['openings']['apttime'];
                                StartLength += obj['openings']['nstartlen'] + '^';
                                GapLength += obj['openings']['ngaplen'] + '^';
                                FinishLength += obj['openings']['nfinishlen'] + '^';
                                AppointmentType += obj['openings']['iappttype'] + '^';
                                CheckInTime += obj['openings']['cmstarttime'] + '^';
                                CheckOutTime += obj['openings']['cmfinishtime'] + '^';
                                ResourceId += obj['openings']['iresourceid'] + '^';
                                Genderid += obj['openings']['igenderid'] + '^';
                                ServiceName += obj['openings']['service'] + '^';
                                ServiceEmployee += cemployee + '^';
                                Stime += obj['openings']['cmstarttime'] + '^';
                                Etime += obj['openings']['cmfinishtime'] + '^';
                                scheduledDate += obj['openings']['actual_ddate'] + '^';

                                listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + (date == 0 ? aptd[1] + "/" + aptd[2] + "/" + aptd[0] : "") + '<br />' + obj['openings']['apttime'] + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['openings']['service'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"><p><span >' + (pric != "0.00" ? "$" + pric : " - ") + '</span></p></div></div></li>';
                                date++;
                                if (o % obj['num_services'] == 0) {
                                    listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + obj['openings']['ddate'] + 'T00:00:00"  date-ScheduledDate="' + scheduledDate + '" date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                    total = 0;
                                    ServiceIds = "";
                                    EmployeeId = "";
                                    StartTime = "";
                                    StartLength = "";
                                    GapLength = "";
                                    FinishLength = "";
                                    AppointmentType = "";
                                    CheckInTime = "";
                                    CheckOutTime = "";
                                    ResourceId = "";
                                    Genderid = "";
                                    ServiceName = "";
                                    ServiceEmployee = "";
                                    Stime = "";
                                    Etime = "";
                                    scheduledDate = "";
                                    date = 0;
                                }
                                o++;

                                if (aptdate != "Inv") {
                                    $(".aptdate").html(moment(obj['openings']['ddate']).format('MMMM Do YYYY'));
                                }
                                $("#bookcontet").html(listItems);
                                // $.post(base_url+"/booker/salonname", {salon_id: salon_id}).done(function(data){
                                //     $("#aptloc").html(data);  
                                //     });
                            }
                        }
                    } else {
                        $("#bookcontet").html("<strong>There were no results based on your current search. please choose another date.</strong>");
                        //$("#bookcontet").html(obj['message']); 
                        var aptdate = new Date(today);
                        var options = {
                            weekday: "long", year: "numeric", month: "short",
                            day: "numeric", hour: "2-digit", minute: "2-digit"
                        };
                        var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                        if (aptdate != "Inv") {
                            $(".aptdate").html(moment(aptfdate).format('MMMM Do YYYY'));
                        }
                        //      $.post(base_url+"/booker/salonname", {salon_id: salon_id}).done(function(data){
                        //      $("#aptloc").html(data);  
                        // });

                    }
                    $.post(base_url + "/booker/salonname", {salon_id: salon_id}).done(function (data) {
                        $("#aptloc").html(data);
                    });
                });
    } else if (step == 5)
    {
        var letterNumber = ("^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})");
        //var letterNumber = (/^(?=.*\d)(?=.*[A-Z])[0-9a-zA-Z]{8,}$/);    
        if ($("#firstname").val() == "") {
            $("#firstname").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter first name.");
            $(".loader").fadeOut(3000);
            return false;
        }
        if ($("#lastname").val() == "") {
            $("#lastname").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter lastname.");
            $(".loader").fadeOut(3000);
            return false;
        }
        if ($("#phone").val() == "") {
            $("#phone").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter phone.");
            $(".loader").fadeOut(3000);
            return false;
        } else if ($("#phone").val().length > 10) {
            $("#phone").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Phone is not more than 10 digits");
            $(".loader").fadeOut(3000);
            return false;

        }
        if ($("#remail").val() == "") {
            $("#remail").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter email address.");
            $(".loader").fadeOut(3000);
            return false;
        }
        if (!validateEmail($("#remail").val())) {
            $("#remail").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter valid email address!");
            $(".loader").fadeOut(2000);
            return false;
        }


        if ($("#rpassword").val() == "") {
            $("#rpassword").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter password.");
            $(".loader").fadeOut(3000);
            return false;
        } else if ($("#rpassword").val().length < 8 || $("#rpassword").val().length > 25) {
            $("#rpassword").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Password length should be in between 8 to 25.");
            $(".loader").fadeOut(3000);
            return false;
        } else if (!$("#rpassword").val().match(letterNumber))
        {
            $(".loader").fadeIn(200);
            $(".loader").html("Your password must contain letters and numbers only with at lease one uppercase letter.");
            $(".loader").fadeOut(3000);
            return false;
        }

        var fname = $("#firstname").val();
        var lname = $("#lastname").val();
        var phone = $("#phone").val();
        var email = $("#remail").val();
        var password = $("#rpassword").val();
        //  var emailconfirm = $("#emailconfirm").val();
        var emailconfirm = $("#optInEmail").val();
        //  var textconfirm = $("#textconfirm").val();
        var textconfirm = $("#optInSMS").val();
        var phonetype = $("#phonetype").val();
        var birthday = $("#birthday").val();
        var street_address = $("#street_address").val();
        var city = $("#city").val();
        var state = $("#state").val();
        var zip_code = $("#zip_code").val();
        var salon_id = document.booking.booking_salon_id.value;
        if (salon_id == "") {
            var salon_id = document.booking.salon_id.value;
        }
        var account_id = $("#salon_account_id").val();
        $(".loader").html("Please wait processing...");
        $(".loader").fadeIn(200);
        console.log('firstname=' + fname + '&lastname=' + lname + '&mobile=' + phone + '&email=' + email + '&password=' + password + '&emailconfirm=' + emailconfirm + '&textconfirm=' + textconfirm + '&birthday=' + birthday + '&address=' + street_address + '&city=' + city + '&state=' + state + '&zip_code=' + zip_code);
        $.ajax({
            url: 'https://saloncloudsplus.com/online_booking_api/userregister/' + salon_id,
            data: 'firstname=' + fname + '&lastname=' + lname + '&mobile=' + phone + '&email=' + email + '&password=' + password + '&emailconfirm=' + emailconfirm + '&textconfirm=' + textconfirm + '&birthday=' + birthday + '&address=' + street_address + '&city=' + city + '&state=' + state + '&zip_code=' + zip_code,
            crossDomain: true,
            type: 'POST',
            success: function (data) {
                console.log(data);
                //return false;
                var obj = JSON.parse(data);
                if (obj["status"] == 1) {
                    data2 = obj["clientid"];
                    slc_id = obj["slc_id"];
                    $.post("https://www.salonclouds.plus/booker/usersession", {email: email, clientid: data2, account_id: account_id, slc_id: slc_id}).done(function (data) {});
                    $("#UserAccount").show();
                    $("#Userlogin").hide();
                    $("#myaccount").load(location.href + " #myaccount");
                    if ($("#AppointmentDate").val() != "") {
                        var servicename = document.booking.ServiceName.value;
                        var color = servicename.search(/color/i);
                        //if (color == -1) {
                        document.booking.ClientId.value = obj["clientid"];
                        document.booking.sess_client_id.value = obj["clientid"];
                        $(".loader").fadeOut(200);
                        $(".form_info").hide();
                        $(".secondform_info").hide();
                        $(".fourth_info").hide();
                        $(".fifth_info").hide();
                        $(".appointment").hide();
                        $(".credit_card_data").hide();
                        $(".colorappointmentrequest").hide();
                        $("#step_one").removeClass("active");
                        $("#step_two").removeClass("active");
                        $("#step_three").removeClass("active");
                        $("#step_creditcard").removeClass("active");
                        $("#step_four").addClass("active");
                        $(".bookingconfirmation").show();
                        var adate = document.booking.AppointmentDate.value.split("T");
                        var appointmentdate = adate['0'].split("-");
                        var aptdate = new Date(adate['0']);
                        var options = {
                            weekday: "long", year: "numeric", month: "short",
                            day: "numeric", hour: "2-digit", minute: "2-digit"
                        };
                        var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                        $("#booking_confirm_date").html(appointmentdate[1] + "/" + appointmentdate[2] + "/" + appointmentdate[0]);
                        var salon_app_date = appointmentdate[0] + "-" + appointmentdate[1] + "-" + appointmentdate[2];
                        var ServiceEmployee = document.booking.ServiceEmployee.value.split("^");
                        var ServiceName = document.booking.ServiceName.value.split("^");
                        var Stime = document.booking.Stime.value.split("^");
                        var Etime = document.booking.Etime.value.split("^");
                        var dispservices = "";
                        for (var s = 0; s < (ServiceName.length) - 1; s++) {
                            dispservices += '<div style="border-bottom:1px dotted #ccc;border-top:1px dotted #ccc; margin:8px 0px 8px 0px;"><div class="booking-form-item">' +
                                    '<label class="booking-form-item "><span class="form-label">Requested Service#' + (s + 1) + ': </span>' +
                                    '</label>' +
                                    '<span class="booking-form-input form-input" id="booking_confirm_service">' + ServiceName[s] + ' </span>' +
                                    '</div>' +
                                    '<div class="booking-form-item">' +
                                    '<label class="booking-form-item ">' +
                                    '<span class="form-label">Service Provider#' + (s + 1) + ': </span></label>' +
                                    '<span class="booking-form-input form-input" id="booking_confirm_stylish"> ' + ServiceEmployee[s] + '</span>' +
                                    '</div>' +
                                    '<div class="booking-form-item">' +
                                    '<label class="booking-form-item ">' +
                                    '<span class="form-label">Appointment Time1#' + (s + 1) + ': </span></label>' +
                                    '<span class="booking-form-input form-input">' +
                                    '<span id="booking_confirm_ftime">' + document.booking.StartTime.value + '</span><span> </span><span id="booking_confirm_ttime"></span>' +
                                    '</span>' +
                                    '<br /></div></div>';
                        }
                        $("#booking_services_details").html(dispservices);
                        $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: document.booking.salon_id.value}).done(function (data) {
                            $("#booking_salon_name").html(data);
                        });
                        /*}
                         else {
                         $(".loader").fadeOut(200);                         
                         $(".form_info").hide();
                         $(".secondform_info").hide();
                         $(".fourth_info").hide();
                         $(".fifth_info").hide();
                         $(".appointment").hide();
                         $(".bookingconfirmation").hide();
                         $(".credit_card_data").hide();
                         $(".colorappointmentrequest").show();
                         $("#step_one").removeClass("active");
                         $("#step_two").removeClass("active");
                         $("#step_three").removeClass("active");
                         $("#step_creditcard").removeClass("active");
                         $("#step_four").addClass("active");
                         var adate =document.booking.AppointmentDate.value.split("T");
                         var appointmentdate = adate['0'].split("-");
                         var aptdate = new Date(adate['0']);
                         var options = {
                         weekday: "long", year: "numeric", month: "short",
                         day: "numeric", hour: "2-digit", minute: "2-digit"
                         };
                         var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);  
                         $("#request_client_name").html(fname+" "+lname);
                         $("#request_client_email").html(email);
                         $("#request_client_phone").html(phone); 
                         $("#request_appointment_date").html(appointmentdate[1]+"/"+appointmentdate[2]+"/"+appointmentdate[0]);
                         var ServiceEmployee = document.booking.ServiceEmployee.value.split("^");
                         var ServiceName = document.booking.ServiceName.value.split("^");
                         var Stime = document.booking.Stime.value.split("^");
                         var Etime = document.booking.Etime.value.split("^"); 
                         var dispservices="";
                         for (var s=0;s<(ServiceName.length)-1;s++) {
                         dispservices += '<div style="border-bottom:1px dotted #ccc;border-top:1px dotted #ccc; margin:8px 0px 8px 0px;"><div class="booking-form-item">'+
                         '<label class="booking-form-item "><span class="form-label">Requested Service#'+ (s+1) +': </span>'+
                         '</label>'+
                         '<span class="booking-form-input form-input" id="request_appointment_service">'+ServiceName[s]+' </span>'+             
                         '</div>'+
                         '<div class="booking-form-item">'+
                         '<label class="booking-form-item ">'+
                         '<span class="form-label">Service Provider#'+ (s+1) +': </span></label>'+
                         '<span class="booking-form-input form-input" id="request_appointment_stylish"> '+ServiceEmployee[s]+'</span>'+
                         '</div>'+
                         '<div class="booking-form-item">'+
                         '<label class="booking-form-item ">'+
                         '<span class="form-label">Appointment Time#'+ (s+1) +': </span></label>'+
                         '<span class="booking-form-input form-input">'+
                         '<span id="request_appointment_ttime">'+Stime[s]+'</span><span> </span><span id="request_appointment_ttime"></span>'+
                         '</span>'+
                         '<br /></div></div>';
                         }
                         //$("#booking_confirm_ftime").html($(bid).attr("date-Stime"));
                         $("#booking_services_details").html(dispservices);
                         //$("#request_appointment_ttime").html(document.booking.Stime.value);
                         //$("#booking_confirm_ttime").html(document.booking.Etime.value);
                         //$("#request_appointment_service").html(document.booking.ServiceName.value);
                         //$("#request_appointment_stylish").html(document.booking.ServiceEmployee.value); 
                         $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: document.booking.salon_id.value}).done(function(data){
                         $("#request_salon_name").html(data);  
                         }); 
                         }*/
                    } else {
                        location.reload();
                    }
                } else if (obj["status"] == 2) {
                    $(".loader").fadeOut(200);
                    if (obj["phone"] != "null") {
                        var mphone = obj["phone"];
                        var n = mphone.length;
                        var f = mphone.substr(0, 3);
                        var star = "";
                        for (var i = 1; i <= (n - 3); i++) {
                            star += "*";
                        }
                        mphone = f + star;
                    }
                    var femail = (obj["email"]);
                    var femail = femail.split("@");
                    var n = femail[0].length;
                    var f = femail[0].substr(0, 2);
                    var star = "";
                    for (var i = 1; i <= (n - 2); i++) {
                        star += "*";
                    }
                    femail = f + star + "@" + femail[1];
                    var p = "";
                    if (obj["phone"] != "null" && obj["phone"] != "") {
                        var p = "<input type='radio' name='forgotpassword' value='phone'  id='forgotpassword' align='absmiddle' /> Send password to phone " + mphone;
                    }
                    var htmld = "<p style='color:#000;'>An account already exists with this email.<br />Please choose below option to get password." +
                            "<br /><br /><table style='color:#000;font-size:14px;'><tr><td><input type='radio' checked name='forgotpassword' value='email' id='forgotpassword' align='absmiddle' /> Send password to email " + femail +
                            "</td></tr><tr><td>" + p + "<input type='hidden'name='forgotpassword_salon_id' value=" + obj["salon_id"] + "  id='forgotpassword_salon_id' /></td></tr></table>" +
                            "<input type='hidden' name='forgotpassword_user_id' value=" + obj["id"] + "  id='forgotpassword_user_id' />" +
                            "<input type='hidden' name='forgotpassword_email' value=" + obj["email"] + "  id='forgotpassword_email' />" +
                            "<input type='hidden' name='forgotpassword_phone' value=" + obj["phone"] + "  id='forgotpassword_phone' />" +
                            "<br /><br /><input type='button' onclick='sendpassword();' style='background:#666;color:#FFF;' class='btn' value='Send password' /><br /><br /></p>";
                    $("#forgotpassword").fadeIn(200);
                    $(".forgotpasswordform").html(htmld);
                    //$(".loader").html(htmld);
                    //$(".loader").fadeIn(200);
                } else {
                    //$(".loader").html("An error occured. please try again.");
                    $(".loader").html(obj["data"]);
                }
            },
        });
    } else if (step == 6) {

        $(".loader").html("Please wait processing...");
        $(".loader").fadeIn(200);

        String.prototype.replaceAll = function (search, replacement) {
            var target = this;
            return target.split(search).join(replacement);
        };



        salon_id = document.booking.booking_salon_id.value;


        ServiceIds = document.booking.ServiceIds.value;
        //var ServiceIds = ServiceIds.replace("^", ",");
        var ServiceIds = ServiceIds.replaceAll("^", ",");
        var ServiceIds = ServiceIds.substr(0, ServiceIds.length - 1);




        EmployeeId = document.booking.EmployeeIds.value;
        //var EmployeeId = EmployeeId.replace("^", ",");
        var EmployeeId = EmployeeId.replaceAll("^", ",");
        var EmployeeId = EmployeeId.substr(0, EmployeeId.length - 1);

        CheckInTime = document.booking.CheckInTime.value;
        //var CheckInTime = CheckInTime.replace("^", ",");
        var CheckInTime = CheckInTime.replaceAll("^", ",");
        var CheckInTime = CheckInTime.substr(0, CheckInTime.length - 1);

        CheckOutTime = document.booking.CheckOutTime.value;
        //var CheckOutTime = CheckOutTime.replace("^", ",");
        var CheckOutTime = CheckOutTime.replaceAll("^", ",");
        var CheckOutTime = CheckOutTime.substr(0, CheckOutTime.length - 1);

        AppointmentDate = document.booking.AppointmentDate.value;
        AppointmentDate = AppointmentDate.split("T");
        AppointmentDate = AppointmentDate[0];


        ServiceEmployee = document.booking.ServiceEmployee.value;
        //var ServiceEmployee = ServiceEmployee.replace("^", ",");
        var ServiceEmployee = ServiceEmployee.replaceAll("^", ",");
        var ServiceEmployee = ServiceEmployee.substr(0, ServiceEmployee.length - 1);

        ServiceName = document.booking.ServiceName.value;
        //var ServiceName = ServiceName.replace("^", ",");
        var ServiceName = ServiceName.replaceAll("^", ",");
        var ServiceName = ServiceName.substr(0, ServiceName.length - 1);

        scheduledDate = document.booking.scheduledDate.value;
        // var scheduledDate = scheduledDate.replace("^", ",");
        var scheduledDate = scheduledDate.replaceAll("^", ",");
        var scheduledDate = scheduledDate.substr(0, scheduledDate.length - 1);

        ClientId = document.booking.sess_client_id.value;

        var obj = '';
        //ankita
        $.post(base_url + "/booking/isServicePreChargableBooker/" + salon_id, $("#booking").serialize()).done(function (data) {
            //$(".bookingconfirmation").hide();
            obj = JSON.parse(data);
            if (obj["total_percentage"] != undefined) {
                if (obj["stripe_status"] == 1) {
                    var pk_key = obj["stripe_live_publishable_key"];
                } else {
                    var pk_key = obj["stripe_test_publishable_key"];
                }
                //ankita : To force the test cc , delete later
                //var pk_key = obj["stripe_test_publishable_key"];
                var toCancel = 0;
                var handler = StripeCheckout.configure({
                    key: pk_key,
                    image: '',
                    locale: 'auto',
                    opened: function () {
                        $('.Header-navClose').hide();
                    },
                    token: function (token) {
                        if (token.id != "") {
                            document.booking.stripe_token.value = token.id;
                            salon_id = document.booking.booking_salon_id.value;
                            ClientId = document.booking.ClientId.value;
                            $.post(base_url + "/API/ws_stripe_booker/" + salon_id, {stripeToken: token.id, Total: (obj["total_percentage"]), ClientId: ClientId})
                                    .done(function (data) {
                                        var obj = JSON.parse(data);
                                        if (obj["status"] == true) {
                                            var transaction_id = obj["transaction_id"];
                                            var transaction_amount = obj["transaction_amount"];
                                            $.post(base_url + "/API/bookingconfirmation/" + salon_id, {AppointmentDate: AppointmentDate, scheduledDate: scheduledDate, ServiceIds: ServiceIds, EmployeeIds: EmployeeId, CheckInTime: CheckInTime, CheckOutTime: CheckOutTime, ServiceNames: ServiceName, ServiceEmployee: ServiceEmployee, ClientId: ClientId, Type: 2})
                                                    .done(function (data) {
                                                        console.log(data);
                                                        var obj = JSON.parse(data);
                                                        $(".loader").fadeOut(200);
                                                        if (obj.status == 0) {
                                                            console.log(obj.status);
                                                            $(".loader").fadeOut(200);
                                                            if (transaction_id != '') {
                                                                $.post(base_url + "/API/booker_releaseamount_notbookedappt/" + salon_id, {transaction_id: transaction_id, transaction_amount: transaction_amount}, function (data) {
                                                                });
                                                            }

                                                            $("#booking_confirm_error").html('<p>An error has occurred while creating appointment.</p>');
                                                            $(".bookingconfirmation").hide();
                                                            $('.secondform_info').show();
                                                            $(".appointment_error").show();
                                                            $(".loader").fadeIn(200).fadeOut(4000);

                                                            return false;
                                                        } else {
                                                            AppointmentId = obj["AppointmentId"];
                                                            $("#apitID").html(AppointmentId);
                                                            if (AppointmentId != 0 || AppointmentId != '')
                                                            {
                                                                $("#booking_confirm_date2").html(AppointmentDate);
                                                                $.ajax({
                                                                    url: 'https://saloncloudsplus.com/online_booking_api/updateapptpaymentstatus',
                                                                    data: 'salon_id=' + salon_id + '&AppointmentId=' + AppointmentId + '&payment_status=1&send_mail=0&transaction_id=' + transaction_id + '&transaction_amount=' + transaction_amount,
                                                                    crossDomain: true,
                                                                    type: 'POST',
                                                                    success: function (response) {
                                                                        $(".bookingconfirmation").hide();
                                                                        $(".appointment").show();
                                                                        $("#booking_confirm_error").hide();
                                                                        $(".appointment_error").hide();
                                                                        console.log(response);
                                                                    },
                                                                    error: function (ErrorResponse) {
                                                                        toCancel = 1;
                                                                        console.log(ErrorResponse);
                                                                    }
                                                                });
                                                            } else
                                                            {
                                                                toCancel = 1;
                                                            }
                                                        }

                                                    });
                                        } else {
                                            $(".bookingconfirmation").hide();
                                            $('.secondform_info').show();
                                            $(".appointment_error").show();
                                            $(".loader").html("There is a problem processing your payment. Please try with a different card, or call the salon to book your appointment.");
                                            $(".loader").fadeIn(200).fadeOut(4000);
                                        }
                                        if (toCancel)
                                        {
                                            //release held CC
                                        }
                                    });
                        } else {
                            $(".bookingconfirmation").hide();
                            $('.secondform_info').show();
                            $(".appointment_error").show();
                            $(".loader").html("There is a problem processing your payment. Please try with a different card, or call the salon to book your appointment.");
                            $(".loader").fadeIn(200).fadeOut(4000);
                        }
                    }
                });
                handler.open({
                    name: "Card Hold",
                    zipCode: false,
                    currency: 'usd',
                    description: '',
                    capture: false,
                    amount: obj["total_percentage"]
                });

            } else {

                $.post(base_url + "/API/bookingconfirmation/" + salon_id, {AppointmentDate: AppointmentDate, scheduledDate: scheduledDate, ServiceIds: ServiceIds, EmployeeIds: EmployeeId, CheckInTime: CheckInTime, CheckOutTime: CheckOutTime, ServiceNames: ServiceName, ServiceEmployee: ServiceEmployee, ClientId: ClientId, Type: 2})
                        .done(function (data) {  //alert(data); return false;  
                            // console.log(data);
                            $(".bookingconfirmation").hide();
                            $(".credit_card_data").hide();
                            $(".loader").fadeOut(200);
                            var obj = JSON.parse(data);//alert(obj["api_create_appt"]);alert(obj["api_create_appt"]["status"]);
                            console.log(data);
                            if (obj.status == 0) {
                                console.log(obj.status);
                                $(".loader").fadeOut(200);
                                $("#booking_confirm_error").html('<p>An error has occurred while creating appointment.</p>');
                                //$(".appointment").show();
                                return false;
                            } else if (obj.status == 2) {
                                $(".form_info").hide();
                                $(".secondform_info").hide();
                                $(".fourth_info").hide();
                                $(".fifth_info").hide();
                                $(".appointment").hide();
                                $("#login").hide();
                                $("#step_one").removeClass("active");
                                $("#step_two").removeClass("active");
                                $("#step_three").removeClass("active");
                                $("#step_four").removeClass("active");
                                $("#step_creditcard").addClass("active");
                                $(".bookingconfirmation").hide();
                                $(".credit_card_data").show();
                            } else {
                                var empty = " ";
                                $("#booking_confirm_error").html(empty);
                                $("#apitID").html(obj.AppointmentId);
                                var adate = document.booking.AppointmentDate.value.split("T");
                                var appointmentdate = adate['0'].split("-");
                                var aptdate = new Date(adate['0']);
                                var options = {
                                    weekday: "long", year: "numeric", month: "short",
                                    day: "numeric", hour: "2-digit", minute: "2-digit"
                                };
                                var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);

                                var ServiceEmployee = document.booking.ServiceEmployee.value.split("^");
                                var ServiceName = document.booking.ServiceName.value.split("^");
                                var Stime = document.booking.Stime.value.split("^");
                                var Etime = document.booking.Etime.value.split("^");
                                var bookingdata = "";
                                for (var s = 0; s < (ServiceName.length) - 1; s++) {
                                    bookingdata += '<table class="booking-completed-details" width="100%"  style="border-bottom:1px dotted #ccc;border-top:1px dotted #ccc;"><tbody><tr class="details-row"><td class="details-label" align="left">Requested Service #' + (s + 1) + ':</td><td class="details-value" align="left">' + ServiceName[s] + ' with ' + ServiceEmployee[s] + '<tr class="details-row"><td class="details-label" align="left">Appointment Time #' + (s + 1) + ':</td><td class="details-value" align="left">' + gettimeformat(Stime[s]) + '</td></tr></td></tr></tbody></table>';
                                }
                                $("#booking_confirm_date2").html(appointmentdate[1] + "/" + appointmentdate[2] + "/" + appointmentdate[0]);
                                $("#booking_confirm_details").html(bookingdata);
                                $(".appointment").show();
                            }
                        });

            }
        });
        //$(".loader").fadeOut(200);

    } else if (step == 7)
    {
        if ($("#email").val() == "") {
            $("#email").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter email.");
            $(".loader").fadeOut(2000);
            return false;
        }
        if (!validateEmail($("#email").val())) {
            $("#email").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("You have entered an invalid email address!");
            $(".loader").fadeOut(2000);
            return false;
        }
        if ($("#password").val() == "") {
            $("#password").focus();
            $(".loader").fadeIn(200);
            $(".loader").html("Please enter password.");
            $(".loader").fadeOut(2000);
            return false;
        }

        var email = $("#email").val();
        var password = $("#password").val();
        var salon_id = $("#booking_salon_id").val();
        if (salon_id == "") {
            var salon_id = $("#salon_id").val();
        }
        var account_id = $("#salon_account_id").val();
        /*02-07-2017*/
        var rem = $('input[name="remember"]:checked').val();
        if (rem == 1) {
            var Remember1 = 1;
        } else {
            var Remember1 = 0;
        }
        /*02-07-2017*/
        $(".loader").html("Please wait processing...");
        $(".loader").fadeIn(200);


        $.ajax({
            url: 'https://saloncloudsplus.com/wsuserlogin/user_login_for_multilocation/' + salon_id,
            data: 'login_email=' + email + '&login_password=' + password + '&salon_id=' + salon_id + '&account_id=' + account_id + '&type=1',
            crossDomain: true,
            type: 'POST',
            success: function (response) {
                var obj = JSON.parse(response);
                if (obj["status"] == 1) {
                    data = obj["clientid"];
                    var slc_id = obj["slc_id"];
                    var isNewClient = obj["isNewClient"];
                    $.post(base_url + "/booker/usersession", {Remember1: Remember1, email: email, password: password, clientid: data, account_id: account_id, slc_id: slc_id, isNewClient: isNewClient}).done(function (data) {});
                } else {
                    data = 'error';
                }
                $(".loader").fadeOut(200);
                if (data == 'error') {
                    $(".loader").fadeIn(200);
                    $(".loader").html("Invalid login details!");
                    $(".loader").fadeOut(2500);
                    //alert("Invalid login details");                                         
                    $(".secondform_info").hide();
                    $(".fourth_info").hide();
                    $(".fifth_info").hide();
                    $(".appointment").hide();
                    $(".bookingconfirmation").hide();
                    $("#step_one").removeClass("active");
                    $("#step_two").removeClass("active");
                    $("#step_three").removeClass("active");
                    $("#step_four").addClass("active");
                    $("#login").show();
                } else {
                    $("#Userlogin").hide();
                    $("#UserAccount").show();
                    document.booking.ClientId.value = data;
                    document.booking.sess_client_id.value = data;
                    document.booking.slc_id.value = slc_id;
                    document.booking.sess_slc_id.value = slc_id;
                    $("#myaccount").load(location.href + " #myaccount");
                    if ($("#AppointmentDate").val() != "") {
                        $(".loader").fadeOut(200);
                        $(".form_info").hide();
                        $(".secondform_info").hide();
                        $(".fourth_info").hide();
                        $(".fifth_info").hide();
                        $("#step_one").removeClass("active");
                        $("#step_two").removeClass("active");
                        $("#step_three").removeClass("active");
                        $("#step_creditcard").removeClass("active");
                        $("#step_four").addClass("active");
                        $(".bookingconfirmation").show();
                        $(".credit_card_data").hide();
                        var adate = document.booking.AppointmentDate.value.split("T");
                        var appointmentdate = adate['0'].split("-");
                        var aptdate = new Date(adate['0']);
                        var options = {
                            weekday: "long", year: "numeric", month: "short",
                            day: "numeric", hour: "2-digit", minute: "2-digit"
                        };
                        var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                        $("#booking_confirm_date").html(appointmentdate[1] + "/" + appointmentdate[2] + "/" + appointmentdate[0]);
                        var ServiceEmployee = document.booking.ServiceEmployee.value.split("^");
                        var ServiceName = document.booking.ServiceName.value.split("^");
                        var Stime = document.booking.Stime.value.split("^");
                        var Etime = document.booking.Etime.value.split("^");
                        var dispservices = "";
                        for (var s = 0; s < (ServiceName.length) - 1; s++) {
                            dispservices += '<div style="border-bottom:1px dotted #ccc;border-top:1px dotted #ccc; margin:8px 0px 8px 0px;"><div class="booking-form-item">' +
                                    '<label class="booking-form-item "><span class="form-label">Requested Service #' + (s + 1) + ': </span>' +
                                    '</label>' +
                                    '<span class="booking-form-input form-input" id="booking_confirm_service">' + ServiceName[s] + ' </span>' +
                                    '</div>' +
                                    '<div class="booking-form-item">' +
                                    '<label class="booking-form-item ">' +
                                    '<span class="form-label">Service Provider #' + (s + 1) + ': </span></label>' +
                                    '<span class="booking-form-input form-input" id="booking_confirm_stylish"> ' + ServiceEmployee[s] + '</span>' +
                                    '</div>' +
                                    '<div class="booking-form-item">' +
                                    '<label class="booking-form-item ">' +
                                    '<span class="form-label">Appointment Time #' + (s + 1) + ': </span></label>' +
                                    '<span class="booking-form-input form-input">' +
                                    '<span id="booking_confirm_ftime">' + document.booking.StartTime.value + '</span><span> </span><span id="booking_confirm_ttime"></span>' +
                                    '</span>' +
                                    '<br /></div></div>';
                        }
                        $("#booking_services_details").html(dispservices);
                        //$("#booking_confirm_ftime").html(document.booking.Stime.value);
                        //$("#booking_confirm_ttime").html(document.booking.Etime.value);
                        //$("#booking_confirm_service").html(document.booking.ServiceName.value);
                        //$("#booking_confirm_stylish").html(document.booking.ServiceEmployee.value);
                        $.post(base_url + "/booking/salonname", {salon_id: salon_id}).done(function (data) {
                            $("#booking_salon_name").html(data);
                        });
                    } else {
                        $("#login").hide();
                        $(".form_info").show();
                        $("#myaccount").load(location.href + " #myaccount");
                        //location.reload();
                    }
                }
            },
            error: function (ErrorResponse) {
                $(".loader").fadeIn(200);
                $(".loader").html("Invalid login details!");
                $(".loader").fadeOut(2500);
                //alert("Invalid login details");                                         
                $(".secondform_info").hide();
                $(".fourth_info").hide();
                $(".fifth_info").hide();
                $(".appointment").hide();
                $(".credit_card_data").hide();
                $(".bookingconfirmation").hide();
                $("#step_one").removeClass("active");
                $("#step_two").removeClass("active");
                $("#step_three").removeClass("active");
                $("#step_creditcard").removeClass("active");
                $("#step_four").addClass("active");
                $("#login").show();
            }
        });
        //}); 
    } else if (step == 4)
    {

        $(".secondform_info").hide();
        $(".fourth_info").hide();
        $(".fifth_info").show();
        $(".appointment").hide();
        $(".bookingconfirmation").hide();
        $(".credit_card_data").hide();
        $("#login").hide();
        $('#forgotpasswordlogin').hide();
        $("#step_one").removeClass("active");
        $("#step_two").removeClass("active");
        $("#step_three").removeClass("active");
        $("#step_creditcard").removeClass("active");
        $("#step_four").addClass("active");
    } else
    {
        $(".form_info").show();
        $(".secondform_info").hide();
        $(".fourth_info").hide();
        $(".fifth_info").hide();
        $(".appointment").hide();
        $(".bookingconfirmation").hide();
        $(".credit_card_data").hide();
        $("#step_one").addClass("active");
        $("#step_two").removeClass("active");
        $("#step_three").removeClass("active");
        $("#step_four").removeClass("active");
        $("#step_creditcard").removeClass("active");
    }
}
function sendpassword() {

    var salon_id = $("#forgotpassword_salon_id").val();
    var uid = $("#forgotpassword_user_id").val();
    var forgotpassword = $('input[name="forgotpassword"]:checked').val();
    var forgotpassword_email = $("#forgotpassword_email").val();
    var forgotpassword_phone = $("#forgotpassword_phone").val();
    /* $.post("https://salonclouds.plus/BookerApi_web/forgotpassword", { option: forgotpassword, uid: uid, email: forgotpassword_email, phone: forgotpassword_phone,salon_id: salon_id}).done(function(data){
     $("#forgotpassword").fadeIn(200);
     $(".forgotpasswordform").html(data); 
     }); */

    $.ajax({
        url: 'https://saloncloudsplus.com/online_booking_api/BookerApi_web_forgotpassword',
        data: 'salon_id=' + salon_id + '&option=' + forgotpassword + '&uid=' + uid + '&email=' + forgotpassword_email + '&phone=' + forgotpassword_phone,
        crossDomain: true,
        type: 'POST',
        success: function (response) {
            $("#forgotpassword").fadeIn(200);
            $(".forgotpasswordform").html(response);
        },
        error: function (ErrorResponse) {
        }
    });

}
function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
function getbookingdeails(bid) {
    document.booking.booking_salon_id.value = $(bid).attr("date-salon_id");
    document.booking.StartTime.value = $(bid).attr("date-StartTime");
    document.booking.ServiceIds.value = $(bid).attr("date-ServiceIds");
    document.booking.EmployeeIds.value = $(bid).attr("date-EmployeeId");
    document.booking.StartLength.value = $(bid).attr("date-StartLength");
    document.booking.GapLength.value = $(bid).attr("date-GapLength");
    document.booking.FinishLength.value = $(bid).attr("date-FinishLength");
    document.booking.AppointmentType.value = $(bid).attr("date-AppointmentType");
    document.booking.CheckInTime.value = $(bid).attr("date-CheckInTime");
    document.booking.CheckOutTime.value = $(bid).attr("date-CheckOutTime");
    document.booking.ResourceId.value = $(bid).attr("date-ResourceId");
    document.booking.Genderid.value = $(bid).attr("date-Genderid");
    document.booking.AppointmentDate.value = $(bid).attr("date-AppointmentDate");
    document.booking.scheduledDate.value = $(bid).attr("date-ScheduledDate");
    document.booking.ServiceEmployee.value = $(bid).attr("date-ServiceEmployee");
    document.booking.ServiceName.value = $(bid).attr("date-ServiceName");
    document.booking.Stime.value = $(bid).attr("date-Stime");
    document.booking.Etime.value = $(bid).attr("date-Etime");
    document.booking.Prices.value = $(bid).attr("date-Prices");

    if (document.booking.sess_client_id.value != "" && document.booking.sess_client_id.value != "0") {
        $(".form_info").hide();
        $(".secondform_info").hide();
        $(".fourth_info").hide();
        $(".fifth_info").hide();
        $(".appointment").hide();
        $("#login").hide();
        $("#step_one").removeClass("active");
        $("#step_two").removeClass("active");
        $("#step_three").removeClass("active");
        $("#step_four").addClass("active");
        $("#step_creditcard").removeClass("active");
        $(".bookingconfirmation").show();
        $(".credit_card_data").hide();
        var adate = $(bid).attr("date-AppointmentDate").split("T");
        var aptdate = new Date(adate['0']);
        var appointmentdate = adate['0'].split("-");
        var options = {
            weekday: "long", year: "numeric", month: "short",
            day: "numeric", hour: "2-digit", minute: "2-digit"
        };
        var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
        $("#booking_confirm_date").html(appointmentdate[1] + "/" + appointmentdate[2] + "/" + appointmentdate[0]);
        var salon_app_date = appointmentdate[0] + "-" + appointmentdate[1] + "-" + appointmentdate[2];
        var ServiceEmployee = document.booking.ServiceEmployee.value.split("^");
        var ServiceName = document.booking.ServiceName.value.split("^");
        var Stime = document.booking.Stime.value.split("^");
        var Etime = document.booking.Etime.value.split("^");

        var CheckInTime = document.booking.CheckInTime.value.split("^");
        var dispservices = "";
        for (var s = 0; s < (ServiceName.length) - 1; s++) {

            dispservices += '<div style="border-bottom:1px dotted #ccc;border-top:1px dotted #ccc; margin:8px 0px 8px 0px;"><div class="booking-form-item">' +
                    '<label class="booking-form-item "><span class="form-label">Requested Service#' + (s + 1) + ': </span>' +
                    '</label>' +
                    '<span class="booking-form-input form-input" id="booking_confirm_service">' + ServiceName[s] + ' </span>' +
                    '</div>' +
                    '<div class="booking-form-item">' +
                    '<label class="booking-form-item ">' +
                    '<span class="form-label">Service Provider#' + (s + 1) + ': </span></label>' +
                    '<span class="booking-form-input form-input" id="booking_confirm_stylish"> ' + ServiceEmployee[s] + '</span>' +
                    '</div>' +
                    '<div class="booking-form-item">' +
                    '<label class="booking-form-item ">' +
                    '<span class="form-label">Appointment Time #' + (s + 1) + ': </span></label>' +
                    '<span class="booking-form-input form-input">' +
                    '<span id="booking_confirm_ftime">' + moment(CheckInTime[s], "HHmm").format("hh:mm A") + '</span><span> </span><span id="booking_confirm_ttime"></span>' +
                    '</span>' +
                    '<br /></div></div>';
        }
        //$("#booking_confirm_ftime").html($(bid).attr("date-Stime"));
        $("#booking_services_details").html(dispservices);
        //$("#booking_confirm_ttime").html(document.booking.Etime.value);
        //$("#booking_confirm_service").html($(bid).attr("date-ServiceName"));
        //$("#booking_confirm_stylish").html($(bid).attr("date-ServiceEmployee")); 
        $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: document.booking.salon_id.value}).done(function (data) {
            $("#booking_salon_name").html(data);
        });
    } else {

        $(".form_info").hide();
        $(".secondform_info").hide();
        $(".fourth_info").hide();
        $(".fifth_info").hide();
        $(".appointment").hide();
        $(".bookingconfirmation").hide();
        $(".credit_card_data").hide();
        $("#login").show();
        $("#step_one").removeClass("active");
        $("#step_two").removeClass("active");
        $("#step_three").removeClass("active");
        $("#step_creditcard").removeClass("active");
        $("#step_four").addClass("active");
    }

}
function loginshow() {
    $(".form_info").hide();
    $(".secondform_info").hide();
    $(".fourth_info").hide();
    $(".fifth_info").hide();
    $(".appointment").hide();
    $(".bookingconfirmation").hide();
    $(".credit_card_data").hide();
    $("#login").show();
    $("#step_one").removeClass("active");
    $("#step_two").removeClass("active");
    $("#step_three").removeClass("active");
    $("#step_creditcard").removeClass("active");
    $("#step_four").addClass("active");
}
function rescandateopenings(ServiceId, EmployeeId, FromDate, ToDate, FromTime, ToTime, salon_id) {

    var aptfdate = $("#aptfromdate").val();
    var newdate = new Date(aptfdate);

    newdate.setDate(newdate.getDate() + 1);

    var dd = ("0" + newdate.getDate()).slice(-2);
    var mm = ("0" + (newdate.getMonth() + 1)).slice(-2);
    var y = newdate.getFullYear();

    var FromDate = (y + '-' + mm + '-' + dd);
    var ToDate = FromDate;
    $("#aptfromdate").val(mm + '/' + dd + '/' + y);
    $("#apttodate").val(mm + '/' + dd + '/' + y);
    if ($("#apttime").val() == "anytime") {
        var FromTime = '08:00:00';
        var ToTime = '21:00:00';
    } else if ($("#apttime").val() == "morning") {
        var FromTime = '08:00:00';
        var ToTime = '11:30:00';
    } else if ($("#apttime").val() == "afternoon") {
        var FromTime = '12:00:00';
        var ToTime = '16:30:00';
    } else if ($("#apttime").val() == "evening") {
        var FromTime = '17:00:00';
        var ToTime = '21:00:00';
    } else {
        var FromTime = '08:00:00';
        var ToTime = '21:00:00';
    }
    $("#cdate").html(mm + '/' + dd + '/' + y);
    ServiceId = serealizeSelects($('.selected_services'));
    EmployeeId1 = serealizeemployees($('.selected_employees'));
//alert( ServiceId + " " + FromDate + " "+ ToDate + " "+ FromTime + " " + ToTime+ " " + EmployeeId+ " " + salon_id);return false;
    $(".loader").html("Please wait searching for openings...");
    $(".loader").fadeIn(200);
    $.post("https://www.salonclouds.plus/BookerApi_web/ScanForOpening", {ServiceId: ServiceId, EmployeeId: EmployeeId1, FromDate: FromDate, ToDate: ToDate, FromTime: FromTime, ToTime: ToTime, salon_id: salon_id})
            .done(function (data) {
                //if(data==""){$("#bookcontet").html("<strong>Sorry, there were no results based on your current search. </strong>"); }salon_id
                $(".loader").fadeOut(200);
                var obj = JSON.parse(data);

                listItems = "";
                if ((obj['status'] == 1) && data != "") {
                    if (data.length > 2) {
                        if (obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'].length != undefined) {
                            var o = 1;
                            var total = 0;
                            EmployeeId = "";
                            ServiceIds = "";
                            StartTime = "";
                            StartLength = "";
                            GapLength = "";
                            FinishLength = "";
                            AppointmentType = "";
                            CheckInTime = "";
                            CheckOutTime = "";
                            ResourceId = "";
                            Genderid = "";
                            ServiceName = "";
                            ServiceEmployee = "";
                            Stime = "";
                            Etime = "";
                            listItems += '<div class="booklist"><ul>';
                            var date = 0;
                            for (var x = 0; x < obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'].length; x++) {

                                //alert(obj['openingcur'][x]['cstarttime'] + ' - ' + obj['openingcur'][x]['cfinishtime']);
                                // <span>-</span><p><span>' + obj['openingcur'][x]['cfinishtime'] +'</span></p>
                                // var aptdate = new Date(obj['openingcur'][x]['ddate']);

                                var aptdate = new Date(FromDate);

                                var options = {
                                    weekday: "long", year: "numeric", month: "short",
                                    day: "numeric", hour: "2-digit", minute: "2-digit"
                                };
                                var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                                var aptd = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['StartDateTime'].split("T");
                                var endtime = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['EndDateTime'].split("T");
                                // var pric = parseFloat(obj['ScheduleItems'][x]['nprice']).toFixed(2);
                                //total =total+pric;

                                var cemployee = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['Staff']['Name'];

                                ServiceIds += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['SessionType']['ID'] + '^';
                                EmployeeId += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['Staff']['ID'] + '^';
                                StartTime += aptd[1] + '^';
                                //StartLength += obj['ScheduleItems'][x]['nstartlen'] + '^';
                                //GapLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                                //FinishLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                                // AppointmentType += obj['ScheduleItems'][x]['iappttype'] + '^';
                                // CheckInTime += obj['ScheduleItems'][x]['cmstarttime'] + '^';
                                //CheckOutTime += obj['ScheduleItems'][x]['cmfinishtime'] + '^';
                                // ResourceId += obj['ScheduleItems'][x]['iresourceid'] + '^';
                                // Genderid += obj['ScheduleItems'][x]['igenderid'] + '^';

                                ServiceName += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['SessionType']['Name'] + '^';
                                ServiceEmployee += cemployee + '^';
                                Stime += aptd[1] + '^';
                                Etime += endtime[1] + '^';

                                listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + moment(obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['StartDateTime']).format('MM/D/YYYY hh:mm A') + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'][x]['SessionType']['Name'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"></div></div></li>';

                                date++;
                                if (o % obj['numser'] == 0) {
                                    listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + aptd[0] + 'T00:00:00" date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                    if (x != (obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem'].length) - 1) {
                                        listItems += '<div class="booklist"><ul>';
                                    }
                                    total = 0;
                                    ServiceIds = "";
                                    EmployeeId = "";
                                    StartTime = "";
                                    StartLength = "";
                                    GapLength = "";
                                    FinishLength = "";
                                    AppointmentType = "";
                                    CheckInTime = "";
                                    CheckOutTime = "";
                                    ResourceId = "";
                                    Genderid = "";
                                    ServiceName = "";
                                    ServiceEmployee = "";
                                    Stime = "";
                                    Etime = "";
                                    date = 0;
                                }
                                o++;

                                //if(aptdate!="Inv"){$(".aptdate").html(moment(obj['openingcur'][0]['ddate']).format('MMMM Do YYYY'));}
                                $("#bookcontet").html(listItems);
                                $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: salon_id}).done(function (data) {
                                    $("#aptloc").html(data);
                                });
                            }
                        } else
                        {


                            var o = 1;
                            var total = 0;
                            EmployeeId = "";
                            ServiceIds = "";
                            StartTime = "";
                            StartLength = "";
                            GapLength = "";
                            FinishLength = "";
                            AppointmentType = "";
                            CheckInTime = "";
                            CheckOutTime = "";
                            ResourceId = "";
                            Genderid = "";
                            ServiceName = "";
                            ServiceEmployee = "";
                            Stime = "";
                            Etime = "";
                            listItems += '<div class="booklist"><ul>';
                            var date = 0;
                            var aptdate = new Date(aptfdate);
                            var options = {
                                weekday: "long", year: "numeric", month: "short",
                                day: "numeric", hour: "2-digit", minute: "2-digit"
                            };
                            var aptd = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['StartDateTime'].split("T");
                            var endtime = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['EndDateTime'].split("T");
                            // var pric = parseFloat(obj['ScheduleItems'][x]['nprice']).toFixed(2);
                            //total =total+pric;

                            var cemployee = obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['Staff']['Name'];

                            ServiceIds += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['SessionType']['ID'] + '^';
                            EmployeeId += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['Staff']['ID'] + '^';
                            StartTime += aptd[1] + '^';
                            //StartLength += obj['ScheduleItems'][x]['nstartlen'] + '^';
                            //GapLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                            //FinishLength += obj['ScheduleItems'][x]['ngaplen'] + '^';
                            // AppointmentType += obj['ScheduleItems'][x]['iappttype'] + '^';
                            // CheckInTime += obj['ScheduleItems'][x]['cmstarttime'] + '^';
                            //CheckOutTime += obj['ScheduleItems'][x]['cmfinishtime'] + '^';
                            // ResourceId += obj['ScheduleItems'][x]['iresourceid'] + '^';
                            // Genderid += obj['ScheduleItems'][x]['igenderid'] + '^';

                            ServiceName += obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['SessionType']['Name'] + '^';
                            ServiceEmployee += cemployee + '^';
                            Stime += aptd[1] + '^';
                            Etime += endtime[1] + '^';

                            listItems += '<li style="border-bottom:1px dotted #ccc;"><div class="time"><p><span >' + moment(obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['StartDateTime']).format('MM/D/YYYY hh:mm A') + '</span></p></div><div class="appointment-request"><ul><li><p>' + obj['GetBookableItemsResult']['ScheduleItems']['ScheduleItem']['SessionType']['Name'] + '<span> <br />with </span> ' + cemployee + '</p></li></ul></div><div class="appointment-request"><div class="time"></div></div></li>';

                            date++;
                            if (o % obj['numser'] == 0) {
                                listItems += '<a class="result-button" style="cursor: pointer;" onclick="getbookingdeails(this);" date-ServiceIds="' + ServiceIds + '" date-EmployeeId="' + EmployeeId + '" date-StartTime="' + StartTime + '" date-StartLength="' + StartLength + '" date-GapLength="' + GapLength + '" date-FinishLength="' + FinishLength + '" date-AppointmentType="' + AppointmentType + '" date-CheckInTime="' + CheckInTime + '"  date-CheckOutTime="' + CheckOutTime + '"  date-ResourceId="' + ResourceId + '" date-AppointmentDate="' + aptd[0] + 'T00:00:00" date-Genderid="' + Genderid + '" date-ServiceName="' + ServiceName + '" date-ServiceEmployee="' + ServiceEmployee + '" date-Stime="' + Stime + '" date-Etime="' + Etime + '" date-salon_id="' + salon_id + '">Book</a></ul></div>';
                                total = 0;
                                ServiceIds = "";
                                EmployeeId = "";
                                StartTime = "";
                                StartLength = "";
                                GapLength = "";
                                FinishLength = "";
                                AppointmentType = "";
                                CheckInTime = "";
                                CheckOutTime = "";
                                ResourceId = "";
                                Genderid = "";
                                ServiceName = "";
                                ServiceEmployee = "";
                                Stime = "";
                                Etime = "";
                                date = 0;
                            }
                            o++;

                            //if(aptdate!="Inv"){$(".aptdate").html(moment(obj['openingcur']['ddate']).format('MMMM Do YYYY'));}
                            $("#bookcontet").html(listItems);
                            $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: salon_id}).done(function (data) {
                                $("#aptloc").html(data);
                            });

                        }
                    }

                } else {
                    var aptdate = new Date(FromDate);
                    var options = {
                        weekday: "long", year: "numeric", month: "short",
                        day: "numeric", hour: "2-digit", minute: "2-digit"
                    };
                    var aptdate = aptdate.toLocaleTimeString("en-us", options).slice(0, -9);
                    if (aptdate != "Inv") {
                        $(".aptdate").html(moment(FromDate).format('MMMM Do YYYY'));
                    }
                    $("#bookcontet").html(obj['data']);
                    $.post("https://www.salonclouds.plus/booker/salonname", {salon_id: salon_id}).done(function (data) {
                        $("#aptloc").html(data);
                    });
                    //$("#bookcontet").html("<strong>Sorry, there were no results based on your current search. </strong>"); 
                }
            });
}
function empdetails(eid, salon_id) {
    $.post("https://www.salonclouds.plus/BookerApi_web/employeedetails", {eid: eid, salon_id: salon_id}).done(function (data) {
        $(".empdetails").html(data);
        $("#empdetails").show();
    });

}
function sendloginpassword() {
    var salon_id = $("#salon_id").val();
    var forgotpasswordemail = $("#forgotpasswordemail").val();
    if (forgotpasswordemail == "") {
        $("#fpm").html("Please enter your email address.");
        return false;
    }
    if (!validateEmail($("#forgotpasswordemail").val())) {
        $("#fpm").html("Please enter valid email address.");
        return false;
    }
    /* $.post("https://salonclouds.plus/BookerApi_web/forgotloginpassword", {email: forgotpasswordemail, salon_id:salon_id}).done(function(data){
     $(".forgotpasswordcontent").html("");
     $("#fpm").html(data); 
     }); */

    $.ajax({

        url: 'https://saloncloudsplus.com/wsuserlogin/user_forgot_password_for_multilocation/' + salon_id,
        data: 'salon_id=' + salon_id + '&login_email=' + forgotpasswordemail,
        crossDomain: true,
        type: 'POST',
        success: function (response) {
            data = JSON.parse(response);
            if (data['status']) {
                $(".forgotpasswordcontent").html("");
            }
            $("#fpm").html(data['message']);
        },
        error: function (ErrorResponse) {
            $("#fpm").html("An error occurred. Please try again...");
        }
    });
}
function updatepassword() {
    var salon_id = $("#my_salon_id").val();
    var password = $("#password").val();
    var cpassword = $("#cpassword").val();
    var clientid = $("#clientid").val();
    var cid = $("#cid").val();
    if (password == "") {
        $("#perror").css("color", "#ff0000");
        $("#perror").html("Please enter new password.");
        return false;
    }
    if (cpassword == "") {
        $("#perror").html("Please enter confirm password.");
        return false;
    }
    if (password != cpassword) {
        $("#perror").html("Password does not match the confirm password.");
        return false;
    }
    $("#perror").html("Please wait updating your password.");
    /*$.post("https://salonclouds.plusReports/booking/updatepassword", {password: password, salon_id:salon_id, clientid:clientid, cid:cid}).done(function(data){              
     $("#perror").html(data); 
     $("#perror").css("color","#fff");
     });*/
    $.ajax({
        url: 'https://saloncloudsplus.com/online_booking_api/BookerApi_web_updatepassword',
        data: 'salon_id=' + salon_id + '&clientid=' + clientid + '&cid=' + cid + '&password=' + password,
        crossDomain: true,
        type: 'POST',
        success: function (response) {
            $("#perror").html(response);
            $("#perror").css("color", "#fff");
        },
        error: function (ErrorResponse) {
        }
    });
}
function updateprofile() {
    var salon_id = $("#my_salon_id").val();
    var clientid = $("#clientid").val();
    //alert(clientid);return false;
    var cid = $("#cid").val();
    var fullname = $("#fullname").val();
    var gender = $("#gender").val();
    var email = $("#email").val();
    var phone = $("#phone").val();
    var phonetype = $("#phonetype").val();
    var birthday = $("#birthday").val();
    var emailconfirm = $("#emailconfirm").val();
    var textconfirm = $("#textconfirm").val();
    if (fullname == "") {
        $("#perror").css("color", "#ff0000");
        $("#perror").html("Please enter your name.");
        return false;
    }
    if (email == "") {
        $("#perror").html("Please enter your email.");
        return false;
    }
    if (!validateEmail(email)) {
        $("#remail").focus();
        $(".loader").fadeIn(200);
        $(".loader").html("Please enter valid email address.");
        $(".loader").fadeOut(2000);
        return false;
    }
    if (phone == "") {
        $("#perror").html("Please enter your phone.");
        return false;
    }
    $("#perror").html("Please wait updating your profile.");
    /* $.post("https://salonclouds.plus/BookerApi_web/updateprofile", {salon_id:salon_id,clientid:clientid,cid:cid,fullname:fullname,gender:gender,email:email,phone:phone,phonetype:phonetype,birthday:birthday,emailconfirm:emailconfirm,textconfirm:textconfirm}).done(function(data){              
     $("#perror").html(data); 
     $("#perror").css("color","#fff");
     }); */
    $.ajax({
        url: 'https://saloncloudsplus.com/online_booking_api/BookerApi_web_updateprofile',
        data: 'salon_id=' + salon_id + '&clientid=' + clientid + '&cid=' + cid + '&fullname=' + fullname + '&gender=' + gender + '&email=' + email + '&phone=' + phone + '&phonetype=' + phonetype + '&birthday=' + birthday + '&emailconfirm=' + emailconfirm + '&textconfirm=' + textconfirm,
        crossDomain: true,
        type: 'POST',
        success: function (response) {
            alert(response);
            $("#perror").html(response);
            $("#perror").css("color", "#fff");
        },
        error: function (ErrorResponse) {
        }
    });
}
function bookNow(obj, showStripe, card_last4 = '')
{
    booked = 1;
    var allDataObj = '';
    if (showStripe == 1) {
        if (obj["stripe_status"] == 1) {
            var pk_key = obj["stripe_live_publishable_key"];
        } else {
            var pk_key = obj["stripe_test_publishable_key"];
        }
        //ankita : To force the test cc , delete later
        //  var pk_key = obj["stripe_test_publishable_key"];
        // var pk_key = 'pk_test_n6hMniJR3jJnHE6HpNeyx3OA';
        var toCancel = 0;
        var handler = StripeCheckout.configure({
            key: pk_key,
            image: '',
            locale: 'auto',
            opened: function () {
                $('.Header-navClose').hide();
            },
            token: function (token) {
                if (token.id != "") {
                    document.booking.stripe_token.value = token.id;
                    salon_id = document.booking.booking_salon_id.value;
                    ClientId = document.booking.ClientId.value;
                    $.post(base_url + "/API/ws_stripe/" + salon_id, {stripeToken: token.id, Total: (obj["total_percentage"]), slc_id: document.booking.slc_id.value})
                            .done(function (data) {
                                var obj = JSON.parse(data);
                                if (obj["status"] == true) {
                                    var transaction_id = obj["transaction_id"];
                                    var transaction_amount = obj["transaction_amount"];
                                    var card_last4 = obj["card_data"]['card_last4'];
                                    $.post(base_url + "/booking/bookingconfirmation/" + salon_id, $("#booking").serialize())
                                            .done(function (data) {
                                                console.log(data);
                                                var obj = JSON.parse(data);
                                                allDataObj = JSON.parse(data);
                                                $(".loader").fadeOut(200);
                                                AppointmentId = obj["AppointmentId"];
                                                $("#apitID").html(AppointmentId);
                                                if (AppointmentId != 0 || AppointmentId != '')
                                                {
                                                    $.ajax({
                                                        url: 'https://saloncloudsplus.com/online_booking_api/updateapptpaymentstatus',
                                                        data: 'salon_id=' + salon_id + '&AppointmentId=' + AppointmentId + '&payment_status=1&send_mail=0&transaction_id=' + transaction_id + '&transaction_amount=' + transaction_amount + '&card_last4=' + card_last4,
                                                        crossDomain: true,
                                                        type: 'POST',
                                                        success: function (response) {
                                                            $(".bookingconfirmation").hide();
                                                            $(".appointment").show();
                                                            $("#cart-badge").html('0');
                                                            mainServices = [];
                                                            $("#AppointmentId").val(AppointmentId);
                                                            console.log(response);
                                                        },
                                                        error: function (ErrorResponse) {
                                                            toCancel = 1;
                                                            console.log(ErrorResponse);
                                                        }
                                                    });
                                                } else
                                                {
                                                    toCancel = 1;
                                                }
                                                if (booked == 1) {
                                                    $.post(base_url + "/booking/salonname", {salon_id: document.booking.booking_salon_id.value}).done(function (data) {
                                                        $("#booking_salon_name2").html(data);
                                                    });
                                                    trackAnalytics(allDataObj, aptdate);
                                                }

                                            });

                                } else {
                                    booked = 0;
                                    $(".bookingconfirmation").hide();
                                    $('.secondform_info').show();
                                    $(".appointment_error").show();
                                    $(".loader").html("There is a problem processing your payment. Please try with a different card, or call the salon to book your appointment.");
                                    $(".loader").fadeIn(200).fadeOut(4000);
                                }
                                if (toCancel)
                                {
                                    //release held CC
                                }
                            });
                } else {
                    booked = 0;
                    $(".bookingconfirmation").hide();
                    $('.secondform_info').show();
                    $(".appointment_error").show();
                    $(".loader").html("There is a problem processing your payment. Please try with a different card, or call the salon to book your appointment.");
                    $(".loader").fadeIn(200).fadeOut(4000);
                }
            }
        });
        handler.open({
            name: "Card Information",
            zipCode: false,
            currency: 'usd',
            description: '',
            capture: false
        });

    } else {
        $("#savedCardsModal").fadeOut(1800);
        $(".bookingconfirmation").hide();
        salon_id = document.booking.booking_salon_id.value;
        $.post(base_url + "/booking/bookingconfirmation/" + salon_id, $("#booking").serialize()).done(function (data) {
            var bookedObj = JSON.parse(data);
            allDataObj = JSON.parse(data);
            $(".loader").fadeOut(200);
            $("#apitID").html(bookedObj["AppointmentId"]);
            $.post(base_url + "/booking/salonname", {salon_id: document.booking.booking_salon_id.value}).done(function (data) {
                $("#booking_salon_name2").html(data);
            });
            salonid = document.booking.booking_salon_id.value;
            if (bookedObj["AppointmentId"] != 0 && data != 0) { //booked sucessfully
                AppointmentId = bookedObj["AppointmentId"];
                if (obj["total_percentage"] != undefined) { //saved card
                    $.ajax({
                        url: 'https://saloncloudsplus.com/online_booking_api/updateapptpaymentstatus',
                        data: 'salon_id=' + salon_id + '&AppointmentId=' + AppointmentId + '&payment_status=1&send_mail=0&transaction_id=' + 'saved_card' + '&transaction_amount=' + obj["total_percentage"] + '&card_last4=' + card_last4,
                        crossDomain: true,
                        type: 'POST',
                        success: function (response) {
                            $(".bookingconfirmation").hide();
                            $(".appointment").show();
                            $("#cart-badge").html('0');
                            mainServices = [];
                            $("#AppointmentId").val(AppointmentId);
                            console.log(response);
                        },
                        error: function (ErrorResponse) {
                            toCancel = 1;
                            console.log(ErrorResponse);
                        }
                    });
                } else { // payment not required
                    $(".bookingconfirmation").hide();
                    $(".appointment").show();
                    $("#cart-badge").html('0');
                    mainServices = [];
                    $("#AppointmentId").val(AppointmentId);
                }
            } else if (bookedObj["AppointmentId"] == -1) {
                $(".appointment_client_error").show();
                booked = 0;
            } else {
                $(".appointment_error").show();
                booked = 0;
            }
            if (booked == 1) {
                if (salon_id == 595 || salonid == 596 || salonid == 597 || salonid == 765) {
                    location.href = base_url + "/onlinebooking/appointments/thank-you";
                }
                trackAnalytics(allDataObj, aptdate);
            }
        });
}
}
function trackAnalytics(allDataObj, aptdate)
{

    if (salon_id.value == 145) {
        gtag('event', 'conversion', {'send_to': 'AW-813979263/L0CVCMSK4n8Q_6yRhAM'});
        return;
    }

    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    function analytics() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    analytics('js', new Date());

    if (salon_id == 53) {
        analytics('config', 'UA-55353593-1');
    } else if (salon_id == 778) {
        analytics('config', 'UA-133557825-1');
    } else if (salon_id == 536 || salon_id == 537 || salon_id == 538 || salon_id == 539 || salon_id == 540) { //Joseph & Friends
        analytics('config', 'UA-123658320-1');
    }

    function requestAppGtag(name, email, phone, service, service_providers, appdate) {
        analytics('event', 'Request Appointment', {
            'dimension1': name,
            'dimension2': email,
            'dimension3': phone,
            'dimension4': service,
            'dimension5': service_providers,
            'dimension6': appdate
                    //,'dimension12': origin
        });
    }
    requestAppGtag(allDataObj['clientdetails']['name'], allDataObj['clientdetails']['email'], allDataObj['clientdetails']['phone'], document.booking.ServiceName.value, document.booking.ServiceEmployee.value, aptdate);

    if (salon_id == 556 || salon_id == 800 || salon_id == 1243 || salon_id == 1247) {
        !function (f, b, e, v, n, t, s)
        {
            if (f.fbq)
                return;
            n = f.fbq = function () {
                n.callMethod ?
                        n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq)
                f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
                'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1610312048996010');
        fbq('track', 'PageView');
        fbq('track', 'ViewContent');
        fbq('track', 'CompleteRegistration');
        fbq('track', 'Lead');

    }
    if (salon_id == 1057) {
        !function (f, b, e, v, n, t, s) {
            if (f.fbq)
                return;
            n = f.fbq = function () {
                n.callMethod ?
                        n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq)
                f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
                'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '936195396568974');
        fbq('track', 'Lead');
    }
    if (salon_id == 1147) {
        fbq('track', 'Purchase', {value: document.booking.Prices.value, currency: 'USD', });
    }

}